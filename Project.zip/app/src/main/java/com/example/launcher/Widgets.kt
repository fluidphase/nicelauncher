package com.example.launcher

import android.app.Activity
import android.app.Dialog
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.ceil
import kotlin.math.max

/** Bottom-sheet widget picker with live previews, grouped by app, with search. */
class WidgetPicker(val act: Activity, val dark: Boolean, val cellW: Float, val cellH: Float, val onPick: (AppWidgetProviderInfo) -> Unit) {
    sealed class Row {
        class Head(val pkg: String, val label: String) : Row()
        class Wid(val info: AppWidgetProviderInfo, val label: String, val sx: Int, val sy: Int) : Row()
    }

    private val pm = act.packageManager
    private val d = act.resources.displayMetrics.density
    private fun dp(v: Float) = (v * d).toInt()
    private val bg = if (dark) 0xFF1E2026.toInt() else 0xFFF4F5F9.toInt()
    private val fg = if (dark) 0xFFF2F3F7.toInt() else 0xFF14161B.toInt()
    private val sub = if (dark) 0xFFA0A5B1.toInt() else 0xFF6B7280.toInt()
    private val cardC = if (dark) 0xFF2A2D35.toInt() else Color.WHITE
    private var dlg: Dialog? = null
    private var rows: List<Row> = emptyList()

    private val groups: List<Triple<String, String, List<Row.Wid>>> by lazy {
        AppWidgetManager.getInstance(act).installedProviders.groupBy { it.provider.packageName }.map { (pkg, l) ->
            val app = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
            Triple(pkg, app, l.map {
                Row.Wid(it, it.loadLabel(pm).toString(), ceil(it.minWidth / max(1f, cellW)).toInt().coerceAtLeast(1), ceil(it.minHeight / max(1f, cellH)).toInt().coerceAtLeast(1))
            }.sortedBy { it.label.lowercase() })
        }.sortedBy { it.second.lowercase() }
    }

    private fun rowsFor(q: String): List<Row> {
        val out = ArrayList<Row>(); val s = q.trim().lowercase()
        for ((pkg, app, l) in groups) {
            val m = if (s.isEmpty() || app.lowercase().contains(s)) l else l.filter { it.label.lowercase().contains(s) }
            if (m.isNotEmpty()) { out.add(Row.Head(pkg, app)); out.addAll(m) }
        }
        return out
    }

    private class HeadVH(val tv: TextView) : RecyclerView.ViewHolder(tv)
    private class WidVH(v: View, val box: FrameLayout, val iv: ImageView, val name: TextView, val size: TextView) : RecyclerView.ViewHolder(v)

    private inner class Ad : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = rows.size
        override fun getItemViewType(p: Int) = if (rows[p] is Row.Head) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, t: Int): RecyclerView.ViewHolder {
            if (t == 0) {
                val tv = TextView(act).apply {
                    textSize = 15f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER_VERTICAL
                    compoundDrawablePadding = dp(10f); setPadding(dp(6f), dp(16f), dp(6f), dp(6f))
                    layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                }
                return HeadVH(tv)
            }
            val iv = ImageView(act)
            val box = FrameLayout(act).apply {
                background = GradientDrawable().apply { setColor(cardC); cornerRadius = dp(18f).toFloat() }
                addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
            val name = TextView(act).apply { textSize = 13f; setTextColor(fg); gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(6f), 0, 0) }
            val size = TextView(act).apply { textSize = 12f; setTextColor(sub); gravity = Gravity.CENTER }
            val root = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(6f), dp(6f), dp(6f), dp(10f))
                layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(100f)))
                addView(name, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                addView(size, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            return WidVH(root, box, iv, name, size)
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, p: Int) {
            val r = rows[p]
            if (r is Row.Head && h is HeadVH) {
                h.tv.text = r.label
                val ic = try { pm.getApplicationIcon(r.pkg) } catch (e: Exception) { null }
                ic?.setBounds(0, 0, dp(24f), dp(24f)); h.tv.setCompoundDrawables(ic, null, null, null)
            } else if (r is Row.Wid && h is WidVH) {
                h.name.text = r.label; h.size.text = "${r.sx} × ${r.sy}"
                h.box.layoutParams.height = (r.sy * dp(34f)).coerceIn(dp(76f), dp(160f))
                val prev = try { r.info.loadPreviewImage(act, 0) } catch (e: Exception) { null }
                if (prev != null) { h.iv.setImageDrawable(prev); h.iv.scaleType = ImageView.ScaleType.FIT_CENTER; h.iv.setPadding(dp(8f), dp(8f), dp(8f), dp(8f)) }
                else { h.iv.setImageDrawable(try { r.info.loadIcon(act, 0) } catch (e: Exception) { null }); h.iv.scaleType = ImageView.ScaleType.FIT_CENTER; h.iv.setPadding(dp(30f), dp(18f), dp(30f), dp(18f)) }
                h.itemView.setOnClickListener { dlg?.dismiss(); onPick(r.info) }
            }
        }
    }

    fun show() {
        if (groups.isEmpty()) { Toast.makeText(act, "No widgets available", Toast.LENGTH_SHORT).show(); return }
        rows = rowsFor("")
        val ad = Ad()
        val dialog = Dialog(act); dlg = dialog
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val r = dp(28f).toFloat()
        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(bg); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f) }
            setPadding(dp(14f), dp(10f), dp(14f), dp(8f))
        }
        root.addView(View(act).apply { background = GradientDrawable().apply { setColor(sub and 0x66FFFFFF); cornerRadius = dp(2f).toFloat() } },
            LinearLayout.LayoutParams(dp(40f), dp(4f)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(10f) })
        root.addView(TextView(act).apply { text = "Widgets"; textSize = 24f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(6f), 0, 0, dp(8f)) })
        val search = EditText(act).apply {
            hint = "Search widgets"; setHintTextColor(sub); setTextColor(fg); textSize = 15f; setSingleLine()
            background = GradientDrawable().apply { setColor(cardC); cornerRadius = dp(22f).toFloat() }
            setPadding(dp(16f), dp(11f), dp(16f), dp(11f))
        }
        root.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4f) })
        val glm = GridLayoutManager(act, 2)
        glm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() { override fun getSpanSize(p: Int) = if (rows[p] is Row.Head) 2 else 1 }
        val rv = RecyclerView(act).apply { layoutManager = glm; adapter = ad; overScrollMode = View.OVER_SCROLL_NEVER; itemAnimator = null }
        root.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { rows = rowsFor(s?.toString() ?: ""); ad.notifyDataSetChanged() }
        })
        dialog.setContentView(root)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(0))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, (act.resources.displayMetrics.heightPixels * 0.86f).toInt())
            setGravity(Gravity.BOTTOM); setDimAmount(0.5f)
            setWindowAnimations(android.R.style.Animation_InputMethod)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        dialog.show()
    }
}
