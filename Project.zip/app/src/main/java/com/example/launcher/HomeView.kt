package com.example.launcher

import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.TypedValue
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.*

class HomeView(val act: MainActivity) : ViewGroup(act) {
    val prefs = Prefs(act)
    val model = Model(act)
    val pages = ArrayList<CellLayout>()
    val dockBg = View(act)
    val dock = CellLayout(act, this).also { it.dockMode = true; it.page = -1 }
    val dots = DotsView(act)
    val pill = TextView(act)
    val scrim = View(act)
    val drawer = DrawerView(act, this)
    val folderLayer = FrameLayout(act)
    val zone = TextView(act)
    val overlay = FrameLayout(act)
    val indicator = View(act)

    var cols = 4; var rows = 5; var dockCols = 4
    var iconPx = 120; var bmpPx = 140; var labelPx = 30f
    var labelColor = Color.WHITE; var frostColor = 0x59FFFFFF
    var cellW = 0f; var cellH = 0f
    var pos = 0f; var curPage = 0
    var drawerP = 0f
    var lastX = 0f; var lastY = 0f
    private var insT = 0; private var insB = 0
    private var bdD = 0f; private var bdF = 0f; private var bd = 0f
    private var geo = ""
    private val slop = ViewConfiguration.get(act).scaledTouchSlop.toFloat()
    private val loc = IntArray(2); private val loc0 = IntArray(2)
    private var posAnim: ValueAnimator? = null
    private var drawerAnim: ValueAnimator? = null
    // swipe
    private var axis = 0; private var sx0 = 0f; private var sy0 = 0f; private var startPos = 0f
    private var vt: VelocityTracker? = null
    // drag
    private var dragging = false; private var pendingCancel = false; private var fromDrawer = false
    private var dragItem: Item? = null; private var dragSrc: CellView? = null; private var ghost: CellView? = null
    private var grabX = 0f; private var grabY = 0f; private var dsx = 0f; private var dsy = 0f; private var dragMoved = false
    private var tgtPage = 0; private var tgtX = 0; private var tgtY = 0; private var tgtMerge: Item? = null; private var tgtValid = false
    private var zoneHot = false; private var edgeDir = 0
    // resize
    private var resizeItem: Item? = null; private var resizeView: CellView? = null; private var rsDrag = false
    // folder
    var folderOpen = false
    private var openFolderItem: Item? = null; private var folderSrc: CellView? = null
    private var folderPanel: View? = null; private var folderTitle: EditText? = null

    init {
        clipChildren = false; clipToPadding = false; isClickable = true
        dockBg.background = rounded(0x59FFFFFF, 40f)
        pill.apply { text = "Search"; gravity = Gravity.CENTER; textSize = 12f; setOnClickListener { openDrawer(true) } }
        scrim.setBackgroundColor(Color.BLACK); scrim.alpha = 0f; scrim.visibility = GONE
        drawer.visibility = GONE
        folderLayer.visibility = GONE; folderLayer.clipChildren = false
        zone.apply { gravity = Gravity.CENTER; textSize = 14f; setTextColor(Color.WHITE); visibility = GONE; alpha = 0f }
        overlay.clipChildren = false
        indicator.background = GradientDrawable().apply { setColor(0x33FFFFFF); setStroke(dpi(1.5f), 0x66FFFFFF) }
        overlay.addView(indicator, FrameLayout.LayoutParams(dpi(60f), dpi(60f)))
        indicator.alpha = 0f
        for (v in listOf<View>(dockBg, dock, dots, pill, scrim, drawer, folderLayer, zone, overlay)) addView(v)
        setOnLongClickListener { showMenu(); true }
        ViewCompat.setOnApplyWindowInsetsListener(this) { _, wi ->
            val b = wi.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            if (b.top != insT || b.bottom != insB) { insT = b.top; insB = b.bottom; drawer.setInsets(insT, insB); requestLayout() }
            wi
        }
    }

    // ---------- lifecycle / data ----------
    fun start() { applyPrefs(); model.load() }

    fun reload() { applyPrefs(); model.load(); Icons.shape = prefs.shape }

    fun applyPrefs() {
        Anim.scale = prefs.animPct / 100f; Icons.shape = prefs.shape
        labelPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, prefs.labelSize.toFloat(), resources.displayMetrics)
        labelColor = if (prefs.darkLabels) 0xFF16181D.toInt() else Color.WHITE
        frostColor = Color.argb((prefs.frost * 2.55f).toInt(), 255, 255, 255)
        dots.dark = prefs.darkLabels
        dockBg.background = rounded(frostColor, dp(30f))
        pill.setTextColor(labelColor); pill.background = rounded(Color.argb((prefs.frost * 1.6f).toInt(), 255, 255, 255), dp(14f))
        WindowCompat.getInsetsController(act.window, this).isAppearanceLightStatusBars = prefs.darkLabels
        geo = ""; requestLayout()
    }

    fun rebuildAll() {
        model.cols = cols; model.rows = rows; model.dockCols = dockCols
        model.fit(); model.sync(prefs.standard, act); model.fit(); model.save()
        ensurePages(max(1, (model.items.maxOfOrNull { it.page } ?: 0) + 1))
        for (p in pages) p.rebuild(model.items.filter { it.page == p.page })
        dock.rebuild(model.items.filter { it.page == -1 })
        requestLayout()
    }

    fun ensurePages(n: Int) {
        while (pages.size < n) { val p = CellLayout(act, this); p.page = pages.size; pages.add(p); addView(p, pages.size - 1) }
        while (pages.size > n) removeView(pages.removeAt(pages.size - 1))
        if (curPage > pages.size - 1) curPage = pages.size - 1
        if (pos > pages.size - 1) pos = (pages.size - 1).toFloat()
        applyPos()
    }

    // ---------- layout ----------
    override fun onMeasure(wm: Int, hm: Int) = setMeasuredDimension(MeasureSpec.getSize(wm), MeasureSpec.getSize(hm))
    private fun lay(v: View, l: Int, t: Int, r: Int, b: Int) {
        v.measure(MeasureSpec.makeMeasureSpec(r - l, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(b - t, MeasureSpec.EXACTLY))
        v.layout(l, t, r, b)
    }

    override fun onLayout(ch: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l; val h = b - t; val d = resources.displayMetrics.density
        val padX = if (w > 600 * d) 28 * d else 10 * d
        val dockH = (88 * d).toInt()
        val pillH = if (prefs.searchPill) (28 * d).toInt() else 0
        val dotsH = if (prefs.indicator) (18 * d).toInt() else 0
        val bottom = dockH + (12 * d).toInt() + (if (pillH > 0) pillH + (8 * d).toInt() else 0) + dotsH + (6 * d).toInt()
        val pageTop = insT + (10 * d).toInt()
        val pageH = max(1, h - insB - bottom - pageTop)
        val nc = if (prefs.cols > 0) prefs.cols else ((w - 2 * padX) / (92 * d)).toInt().coerceIn(4, 12)
        val nr = if (prefs.rows > 0) prefs.rows else (pageH / (104 * d)).toInt().coerceIn(4, 10)
        cellW = (w - 2 * padX) / nc; cellH = pageH.toFloat() / nr
        val ip = (min(cellW * 0.66f, cellH * 0.56f) * prefs.iconScale / 100f).toInt().coerceAtLeast((28 * d).toInt())
        val dc = min(nc, if (w > 600 * d) 7 else 5)
        val key = "$w,$h,$nc,$nr,$dc,$ip,$insT,$insB"
        cols = nc; rows = nr; dockCols = dc; iconPx = ip; bmpPx = (ip * 1.15f).toInt()
        for (p in pages) { p.cols = nc; p.rows = nr; p.padX = padX; lay(p, 0, pageTop, w, pageTop + pageH) }
        val dockW = (dc * cellW).toInt(); val dl = (w - dockW) / 2; val dt = h - insB - dockH - (12 * d).toInt()
        dock.cols = dc; dock.rows = 1; dock.padX = 0f
        lay(dock, dl, dt, dl + dockW, dt + dockH)
        lay(dockBg, dl - (8 * d).toInt(), dt, dl + dockW + (8 * d).toInt(), dt + dockH)
        (dockBg.background as GradientDrawable).cornerRadius = dockH * 0.34f
        val pt = dt - (8 * d).toInt() - pillH
        lay(pill, (w - (92 * d).toInt()) / 2, pt, (w + (92 * d).toInt()) / 2, pt + pillH)
        val dtp = (if (pillH > 0) pt else dt - (6 * d).toInt()) - dotsH
        lay(dots, 0, dtp, w, dtp + dotsH)
        pill.visibility = if (pillH > 0) VISIBLE else GONE; dots.visibility = if (dotsH > 0) VISIBLE else GONE
        for (v in listOf<View>(scrim, drawer, folderLayer, overlay)) lay(v, 0, 0, w, h)
        lay(zone, (w - (220 * d).toInt()) / 2, insT + (14 * d).toInt(), (w + (220 * d).toInt()) / 2, insT + (58 * d).toInt())
        if (key != geo) { geo = key; post { rebuildAll() } }
    }

    // ---------- pager / drawer swipe ----------
    fun applyPos() {
        for ((i, p) in pages.withIndex()) {
            val d = i - pos; val a = min(1f, abs(d))
            p.translationX = d * width
            p.visibility = if (abs(d) > 1.05f) INVISIBLE else VISIBLE
            val s = (1f - 0.08f * a) * (1f - 0.06f * bd); p.scaleX = s; p.scaleY = s
            p.alpha = (1f - 0.6f * a) * (1f - 0.55f * bd)
        }
        dots.pos = pos; dots.count = pages.size; dots.invalidate()
    }

    fun goPage(t: Int) {
        curPage = t; posAnim?.cancel()
        posAnim = anim(pos, t.toFloat(), 420, Anim.out) { pos = it; applyPos() }
    }

    private fun updateBackdrop() {
        bd = max(bdD, bdF)
        scrim.visibility = if (bd > 0.001f) VISIBLE else GONE; scrim.alpha = bd * 0.5f
        applyPos()
        val s = 1f - 0.06f * bd; val a = 1f - 0.55f * bd
        val rest = listOf<View>(dockBg, dock, dots, pill)
        for (v in rest) { v.scaleX = s; v.scaleY = s; v.alpha = a }
        if (Build.VERSION.SDK_INT >= 31) {
            val fx = if (bd > 0.01f) RenderEffect.createBlurEffect(dp(16f) * bd, dp(16f) * bd, Shader.TileMode.CLAMP) else null
            for (v in pages + rest) v.setRenderEffect(fx)
        }
    }

    fun setDrawer(p: Float) {
        drawerP = p.coerceIn(0f, 1f)
        drawer.visibility = if (drawerP > 0.001f) VISIBLE else GONE
        drawer.alpha = min(1f, drawerP * 1.5f); drawer.translationY = (1f - drawerP) * height * 0.18f
        bdD = drawerP; updateBackdrop()
    }
    fun openDrawer(focus: Boolean) {
        if (drawerP == 0f) drawer.refresh()
        drawerAnim?.cancel()
        drawerAnim = anim(drawerP, 1f, 380, Anim.out, end = { if (focus) drawer.openKeyboard() }) { setDrawer(it) }
    }
    fun closeDrawer() {
        drawer.hideKb(); drawerAnim?.cancel()
        drawerAnim = anim(drawerP, 0f, 300, Anim.inOut, end = { drawer.clear() }) { setDrawer(it) }
    }

    private fun track(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                axis = 0; sx0 = e.x; sy0 = e.y; startPos = pos
                vt?.recycle(); vt = VelocityTracker.obtain(); vt!!.addMovement(e)
                posAnim?.cancel(); drawerAnim?.cancel()
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                val dx = e.x - sx0; val dy = e.y - sy0
                if (axis == 0 && max(abs(dx), abs(dy)) > slop) {
                    axis = if (abs(dx) > abs(dy)) 1 else if (dy < 0) 2 else 3
                    startPos = pos
                    if (axis == 2) drawer.refresh()
                }
                if (axis == 1) {
                    val adj = dx - slop * sign(dx)
                    var np = startPos - adj / max(1, width)
                    val last = (pages.size - 1).toFloat()
                    if (np < 0f) np *= 0.3f else if (np > last) np = last + (np - last) * 0.3f
                    pos = np; applyPos()
                } else if (axis == 2) setDrawer(-(dy + slop) / (height * 0.55f))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                vt?.addMovement(e); vt?.computeCurrentVelocity(1000)
                val vx = vt?.xVelocity ?: 0f; val vy = vt?.yVelocity ?: 0f
                if (axis == 1) {
                    val v = dp(600f); var t = pos.roundToInt()
                    if (vx < -v) t = floor(pos).toInt() + 1 else if (vx > v) t = ceil(pos).toInt() - 1
                    goPage(t.coerceIn(0, pages.size - 1))
                } else if (axis == 2) {
                    if (drawerP > 0.3f || vy < -1200f) openDrawer(false) else closeDrawer()
                }
                axis = 0; vt?.recycle(); vt = null
            }
        }
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (dragging || resizeItem != null || drawerP > 0f || folderOpen) return false
        track(e)
        return axis == 1 || axis == 2
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (dragging || resizeItem != null || drawerP > 0f || folderOpen) return true
        track(e)
        super.onTouchEvent(e)
        return true
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        lastX = e.x; lastY = e.y
        if (pendingCancel && (dragging || resizeItem != null)) {
            pendingCancel = false
            val c = MotionEvent.obtain(e); c.action = MotionEvent.ACTION_CANCEL
            super.dispatchTouchEvent(c); c.recycle()
        }
        if (dragging) { dragTouch(e); return true }
        if (resizeItem != null) { resizeTouch(e); return true }
        return super.dispatchTouchEvent(e)
    }

    // ---------- helpers ----------
    fun rectOf(v: View): RectF {
        getLocationInWindow(loc0); v.getLocationInWindow(loc)
        val l = (loc[0] - loc0[0]).toFloat(); val t = (loc[1] - loc0[1]).toFloat()
        return RectF(l, t, l + v.width * v.scaleX, t + v.height * v.scaleY)
    }

    fun launch(pkg: String, cls: String, v: View?) {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(ComponentName(pkg, cls))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val o = if (v != null) ActivityOptions.makeScaleUpAnimation(v, 0, 0, v.width, v.height) else null
            act.startActivity(i, o?.toBundle())
        } catch (e: Exception) { Toast.makeText(act, "Can't open app", Toast.LENGTH_SHORT).show() }
    }

    private fun uninstall(i: Item) { try { act.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${i.pkg}"))) } catch (e: Exception) {} }

    private fun findView(i: Item): CellView? {
        for (p in pages + dock) for (n in 0 until p.childCount) { val v = p.getChildAt(n) as CellView; if (v.item === i) return v }
        return null
    }

    fun onItemClick(v: CellView) {
        val i = v.item
        if (!i.isFolder) launch(i.pkg, i.cls, v)
        else { val k = v.kidAt(v.downX, v.downY); if (k != null) launch(k.pkg, k.cls, v) else openFolder(v) }
    }

    fun onItemLong(v: CellView): Boolean {
        if (prefs.lock || folderOpen || drawerP > 0f) return false
        fromDrawer = false; beginDrag(v.item, v, lastX, lastY); return true
    }

    fun beginDragFromDrawer(a: App): Boolean {
        if (prefs.lock) return false
        fromDrawer = true
        beginDrag(Item(model.newId(), false, a.pkg, a.cls, a.label), null, lastX, lastY)
        closeDrawer(); return true
    }

    fun onBack() {
        when {
            folderOpen -> closeFolder()
            drawerP > 0f -> closeDrawer()
            resizeItem != null -> exitResize()
            dragging -> finishDrag(lastX, lastY, true)
            curPage != 0 -> goPage(0)
        }
    }
    fun onHomePressed() { onBack(); if (drawerP > 0f) closeDrawer(); if (folderOpen) closeFolder(); if (resizeItem != null) exitResize(); if (curPage != 0) goPage(0) }

    private fun showMenu() {
        AlertDialog.Builder(act).setItems(arrayOf("Home settings", "Change wallpaper")) { _, w ->
            if (w == 0) act.startActivity(Intent(act, SettingsActivity::class.java))
            else act.startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
        }.show()
    }

    private fun appMenu(v: CellView) {
        val i = v.item
        val pm = PopupMenu(act, v)
        pm.menu.add(0, 1, 0, "App info"); pm.menu.add(0, 2, 1, "Uninstall")
        if (!prefs.standard) pm.menu.add(0, 3, 2, "Remove from home")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> act.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${i.pkg}")))
                2 -> uninstall(i)
                3 -> { model.items.remove(i); rebuildAll() }
            }
            true
        }
        pm.show()
    }

    // ---------- zone ----------
    private fun showZone(text: String, hot: Boolean) {
        zone.text = text; zone.background = rounded(if (hot) 0xDDE5484D.toInt() else 0x66000000, dp(22f))
        if (zone.visibility != VISIBLE) { zone.visibility = VISIBLE; zone.translationY = -dp(30f) }
        zone.animate().alpha(1f).translationY(0f).setDuration(Anim.d(240)).setInterpolator(Anim.out).start()
    }
    private fun hideZone() {
        zone.animate().alpha(0f).translationY(-dp(30f)).setDuration(Anim.d(200)).setInterpolator(Anim.inOut)
            .withEndAction { if (zone.alpha == 0f) zone.visibility = GONE }.start()
    }
    private fun zoneText(i: Item) = if (i.isFolder) "Dissolve folder" else if (prefs.standard) "Uninstall" else "Remove"

    // ---------- drag & drop ----------
    private fun beginDrag(item: Item, src: CellView?, x: Float, y: Float) {
        dragging = true; pendingCancel = true; dragItem = item; dragSrc = src; dragMoved = false; dsx = x; dsy = y
        tgtValid = false; tgtMerge = null; zoneHot = false
        val g = CellView(act, item, this); g.dock = src?.dock ?: false; g.alwaysLabel = src?.alwaysLabel ?: false
        val r = if (src != null) rectOf(src) else RectF(x - cellW / 2, y - cellH / 2, x + cellW / 2, y + cellH / 2)
        grabX = x - r.left; grabY = y - r.top
        val w = if (src != null) src.width else cellW.toInt(); val h = if (src != null) src.height else cellH.toInt()
        overlay.addView(g, FrameLayout.LayoutParams(w, h))
        g.translationX = r.left; g.translationY = r.top
        g.animate().scaleX(1.12f).scaleY(1.12f).setDuration(Anim.d(240)).setInterpolator(Anim.pop).start()
        src?.alpha = 0f; ghost = g
        showZone(zoneText(item), false)
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun dragTouch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> updateDrag(e.x, e.y)
            MotionEvent.ACTION_UP -> finishDrag(e.x, e.y, false)
            MotionEvent.ACTION_CANCEL -> finishDrag(e.x, e.y, true)
        }
    }

    private val edgeRun = Runnable {
        val dir = edgeDir; edgeDir = 0
        if (!dragging || dir == 0) return@Runnable
        val t = curPage + dir
        if (t < 0) return@Runnable
        if (t >= pages.size) { if (model.items.none { it.page == curPage }) return@Runnable; ensurePages(pages.size + 1) }
        goPage(t); updateDrag(lastX, lastY)
    }
    private fun edge(dir: Int) {
        if (dir == edgeDir) return
        removeCallbacks(edgeRun); edgeDir = dir
        if (dir != 0) postDelayed(edgeRun, 520)
    }

    private fun updateDrag(x: Float, y: Float) {
        val g = ghost ?: return; val item = dragItem ?: return
        g.translationX = x - grabX; g.translationY = y - grabY
        if (!dragMoved && hypot(x - dsx, y - dsy) > slop * 1.5f) dragMoved = true
        val hot = y < insT + dp(84f)
        if (hot != zoneHot) { zoneHot = hot; showZone(zoneText(item), hot) }
        if (hot) { indicator.animate().alpha(0f).setDuration(Anim.d(120)).start(); tgtValid = false; edge(0); return }
        val inDock = y > rectOf(dock).top - dp(14f)
        edge(if (inDock) 0 else if (x < dp(34f)) -1 else if (x > width - dp(34f)) 1 else 0)
        val layout = if (inDock) dock else pages[curPage.coerceIn(0, pages.size - 1)]
        val lr = rectOf(layout); val cw = layout.cellW; val ch = layout.cellH
        val sx = if (inDock) 1 else item.sx; val sy = if (inDock) 1 else item.sy
        val gl = x - grabX; val gt = y - grabY
        val gcx = gl + g.width / 2f; val gcy = gt + g.height / 2f
        val pid = if (inDock) -1 else layout.page
        val fxp = (gcx - lr.left - layout.padX) / cw; val fyp = (gcy - lr.top) / ch
        val ccx = floor(fxp).toInt().coerceIn(0, layout.cols - 1); val ccy = floor(fyp).toInt().coerceIn(0, layout.rows - 1)
        val fx = fxp - ccx; val fy = fyp - ccy
        val other = model.itemAt(pid, ccx, ccy, item)
        tgtMerge = null
        if (other != null && !item.isFolder && (other.isFolder || (other.sx == 1 && other.sy == 1 && fx in 0.22f..0.78f && fy in 0.22f..0.78f))) {
            tgtMerge = other; tgtPage = pid; tgtValid = true
            showIndicator(lr, layout, other.x, other.y, other.sx, other.sy, true)
        } else {
            val ax = round((gl - lr.left - layout.padX) / cw).toInt().coerceIn(0, layout.cols - sx)
            val ay = round((gt - lr.top) / ch).toInt().coerceIn(0, layout.rows - sy)
            val s = model.nearest(pid, ax, ay, sx, sy, item)
            if (s == null) { tgtValid = false; indicator.animate().alpha(0f).setDuration(Anim.d(120)).start() }
            else { tgtValid = true; tgtPage = pid; tgtX = s.first; tgtY = s.second; showIndicator(lr, layout, s.first, s.second, sx, sy, false) }
        }
    }

    private fun showIndicator(lr: RectF, layout: CellLayout, x: Int, y: Int, sx: Int, sy: Int, merge: Boolean) {
        val cw = layout.cellW; val ch = layout.cellH
        var l = lr.left + layout.padX + x * cw; var t = lr.top + y * ch
        var w = sx * cw; var h = sy * ch
        val small = sx == 1 && sy == 1
        if (small) { val s = iconPx + dp(10f); l += (w - s) / 2; t += (ch - s) / 2 - (if (layout.dockMode) 0f else dp(8f)); w = s; h = s }
        else { l += dp(5f); t += dp(5f); w -= dp(10f); h -= dp(10f) }
        val lp = indicator.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w.toInt() || lp.height != h.toInt()) { lp.width = w.toInt(); lp.height = h.toInt(); indicator.layoutParams = lp }
        (indicator.background as GradientDrawable).apply { cornerRadius = if (small) w * 0.3f else dp(28f); setColor(if (merge) 0x66FFFFFF else 0x30FFFFFF) }
        indicator.animate().translationX(l).translationY(t).alpha(1f).setDuration(Anim.d(220)).setInterpolator(Anim.out).start()
    }

    private fun clearDrag() { dragItem = null; dragSrc = null; ghost = null; tgtMerge = null; tgtValid = false; zoneHot = false; fromDrawer = false }

    private fun flyBack(g: CellView, src: CellView?) {
        if (src != null) {
            val r = rectOf(src)
            g.animate().translationX(r.left).translationY(r.top).scaleX(1f).scaleY(1f).setDuration(Anim.d(260)).setInterpolator(Anim.out)
                .withEndAction { overlay.removeView(g); src.alpha = 1f }.start()
        } else g.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).setDuration(Anim.d(200)).withEndAction { overlay.removeView(g) }.start()
    }

    private fun finishDrag(x: Float, y: Float, cancel: Boolean) {
        edge(0); dragging = false
        indicator.animate().alpha(0f).setDuration(Anim.d(150)).start()
        val g = ghost; val item = dragItem; val src = dragSrc
        if (g == null || item == null) { hideZone(); clearDrag(); return }
        if (!cancel && !dragMoved && src != null) {
            hideZone(); clearDrag(); flyBack(g, src)
            if (item.isFolder) enterResize(src) else appMenu(src)
            return
        }
        if (!cancel && zoneHot) { hideZone(); zoneAction(item, g, fromDrawer); clearDrag(); return }
        hideZone()
        if (!cancel && tgtValid) { applyDrop(item, g); return }
        clearDrag(); flyBack(g, src)
    }

    private fun zoneAction(item: Item, g: CellView, fd: Boolean) {
        val std = prefs.standard; val src = dragSrc
        g.animate().alpha(0f).scaleX(0.3f).scaleY(0.3f).setDuration(Anim.d(220)).setInterpolator(Anim.inOut).withEndAction {
            overlay.removeView(g); src?.alpha = 1f
            if (item.isFolder) {
                model.items.remove(item)
                for (k in item.kids) { val (pg, x, y) = model.spot(model.items, 1, 1); k.page = pg; k.x = x; k.y = y; k.sx = 1; k.sy = 1; model.items.add(k) }
            } else if (std) { if (!fd) uninstall(item) } else model.items.remove(item)
            rebuildAll()
        }.start()
    }

    private fun applyDrop(item: Item, g: CellView) {
        val merge = tgtMerge; val pid = tgtPage
        val layout = if (pid == -1) dock else pages[pid.coerceIn(0, pages.size - 1)]
        val lr = rectOf(layout); val cw = layout.cellW; val ch = layout.cellH
        val result: Item; val cx: Float; val cy: Float
        if (merge != null) {
            if (merge.isFolder) { model.items.remove(item); merge.kids.add(Item(item.id, false, item.pkg, item.cls, item.label)); result = merge }
            else {
                val f = Item(model.newId(), true, label = "Folder", page = merge.page, x = merge.x, y = merge.y)
                f.kids.add(merge); f.kids.add(Item(item.id, false, item.pkg, item.cls, item.label))
                model.items[model.items.indexOf(merge)] = f; model.items.remove(item); result = f
            }
            cx = lr.left + layout.padX + (merge.x + merge.sx / 2f) * cw; cy = lr.top + (merge.y + merge.sy / 2f) * ch
        } else {
            item.page = pid; item.x = tgtX; item.y = tgtY
            if (pid == -1) { item.sx = 1; item.sy = 1 }
            if (!model.items.contains(item)) model.items.add(item)
            result = item
            cx = lr.left + layout.padX + (tgtX + item.sx / 2f) * cw; cy = lr.top + (tgtY + item.sy / 2f) * ch
        }
        val src = dragSrc; clearDrag()
        g.animate().translationX(cx - g.width / 2f).translationY(cy - g.height / 2f)
            .scaleX(if (merge != null) 0.5f else 1f).scaleY(if (merge != null) 0.5f else 1f).alpha(if (merge != null) 0.2f else 1f)
            .setDuration(Anim.d(260)).setInterpolator(Anim.out).withEndAction {
                overlay.removeView(g); src?.alpha = 1f
                rebuildAll()
                post { findView(result)?.let { v ->
                    v.scaleX = 0.82f; v.scaleY = 0.82f
                    v.animate().scaleX(1f).scaleY(1f).setDuration(Anim.d(420)).setInterpolator(Anim.pop).start()
                } }
            }.start()
    }

    // ---------- folder resize ----------
    private fun enterResize(v: CellView) {
        if (v.dock) return
        resizeItem = v.item; resizeView = v; v.resizing = true; v.invalidate()
        showZone("Drag the corner to resize · tap outside to finish", false)
        performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
    }
    private fun exitResize() {
        resizeView?.let { it.resizing = false; it.invalidate() }
        resizeItem = null; resizeView = null; rsDrag = false; hideZone(); model.save()
    }
    private fun resizeTouch(e: MotionEvent) {
        val v = resizeView ?: return
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val r = rectOf(v); val b = v.bounds(RectF())
                rsDrag = hypot(e.x - (r.left + b.right), e.y - (r.top + b.bottom)) < dp(44f)
                if (!rsDrag) exitResize()
            }
            MotionEvent.ACTION_MOVE -> if (rsDrag) updateResize(e.x, e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> rsDrag = false
        }
    }
    private fun updateResize(x: Float, y: Float) {
        val v = resizeView ?: return; val item = resizeItem ?: return
        val layout = v.parent as? CellLayout ?: return
        val lr = rectOf(layout)
        val nsx = round((x - (lr.left + layout.padX + item.x * layout.cellW)) / layout.cellW).toInt().coerceIn(1, min(layout.cols - item.x, 5))
        val nsy = round((y - (lr.top + item.y * layout.cellH)) / layout.cellH).toInt().coerceIn(1, min(layout.rows - item.y, 5))
        if ((nsx != item.sx || nsy != item.sy) && model.isFree(item.page, item.x, item.y, nsx, nsy, item)) {
            item.sx = nsx; item.sy = nsy; layout.moveTo(item)
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    // ---------- folder open ----------
    fun openFolder(v: CellView) {
        val f = v.item
        folderOpen = true; openFolderItem = f; folderSrc = v
        folderLayer.removeAllViews(); folderLayer.visibility = VISIBLE
        folderLayer.setOnClickListener { closeFolder() }
        val n = f.kids.size
        val kc = max(3, min(5, ceil(sqrt(n.toFloat())).toInt()))
        val pw = min(width * 0.9f, dp(420f)).toInt()
        val cwid = (pw - dpi(32f)) / kc
        val chei = (iconPx + labelPx * 2 + dp(26f)).toInt()
        val panel = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(0x40FFFFFF, dp(32f)); isClickable = true
            setPadding(dpi(16f), dpi(18f), dpi(16f), dpi(18f))
        }
        val title = EditText(act).apply {
            setText(f.label); setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER; background = null
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_DONE
            setOnEditorActionListener { tv, _, _ ->
                tv.clearFocus()
                (act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(tv.windowToken, 0); true
            }
        }
        val grid = GridLayout(act).apply { columnCount = kc }
        for (k in f.kids) {
            val cv = CellView(act, k, this); cv.alwaysLabel = true
            cv.setOnClickListener { launch(k.pkg, k.cls, cv) }
            cv.setOnLongClickListener { kidMenu(f, k, cv); true }
            grid.addView(cv, GridLayout.LayoutParams().apply { width = cwid; height = chei })
        }
        panel.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panel.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dpi(10f) })
        folderLayer.addView(panel, FrameLayout.LayoutParams(pw, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        folderPanel = panel; folderTitle = title; panel.alpha = 0f
        panel.post {
            val fr = rectOf(v)
            panel.pivotX = fr.centerX() - panel.left; panel.pivotY = fr.centerY() - panel.top
            anim(0f, 1f, 380, Anim.out) { t ->
                panel.alpha = min(1f, t * 2f); val s = 0.3f + 0.7f * t; panel.scaleX = s; panel.scaleY = s
                bdF = t; updateBackdrop()
            }
        }
    }

    fun closeFolder() {
        if (!folderOpen) return
        folderOpen = false
        val p = folderPanel ?: return; val f = openFolderItem
        val nm = folderTitle?.text?.toString()?.trim().orEmpty()
        if (f != null && nm.isNotEmpty() && nm != f.label) { f.label = nm; model.save(); folderSrc?.invalidate() }
        (act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(windowToken, 0)
        anim(1f, 0f, 260, Anim.inOut, end = { folderLayer.visibility = GONE; folderLayer.removeAllViews() }) { t ->
            p.alpha = min(1f, t * 1.5f); val s = 0.3f + 0.7f * t; p.scaleX = s; p.scaleY = s
            bdF = t; updateBackdrop()
        }
    }

    private fun kidMenu(f: Item, k: Item, v: View) {
        val pm = PopupMenu(act, v)
        pm.menu.add(0, 1, 0, "Remove from folder"); pm.menu.add(0, 2, 1, "App info")
        pm.setOnMenuItemClickListener {
            if (it.itemId == 2) act.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${k.pkg}")))
            else {
                f.kids.remove(k)
                val (pg, x, y) = model.spot(model.items, 1, 1); k.page = pg; k.x = x; k.y = y; k.sx = 1; k.sy = 1; model.items.add(k)
                if (f.kids.size == 1) { val l = f.kids[0]; l.page = f.page; l.x = f.x; l.y = f.y; l.sx = 1; l.sy = 1; model.items[model.items.indexOf(f)] = l }
                else if (f.kids.isEmpty()) model.items.remove(f)
                closeFolder(); rebuildAll()
            }
            true
        }
        pm.show()
    }
}
