package com.example.launcher

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import kotlin.math.max

/** Blurred copy of the wallpaper (works on Android 8+, needs storage access to read the wallpaper). */
object Frost {
    @Volatile var bmp: Bitmap? = null
    val views = ArrayList<FrostView>()
    private var key = ""
    @Volatile var status = "Not loaded yet"

    fun hasAccess(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED ||
            (Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager())

    fun load(ctx: Context, w: Int, h: Int, amount: Int, enabled: Boolean, force: Boolean = false) {
if (!enabled) { bmp = null; views.forEach { it.invalidate() }; key = ""; status = "Blur is off"; return }
        if (!hasAccess(ctx)) {
            bmp = null; key = ""; views.forEach { it.invalidate() }
            status = "Wallpaper can't be read - allow wallpaper access below"; return
        }
        val k = "$w,$h,$amount"
        if (w <= 0 || h <= 0 || (!force && k == key && bmp != null)) return
        key = k
        val app = ctx.applicationContext
        Thread {
            val b = try { build(app, w, h, amount) } catch (e: Throwable) { null }
            Handler(Looper.getMainLooper()).post {
                bmp = b; status = if (b != null) "Active" else "Couldn't read the wallpaper (live wallpapers can't be blurred)"
                views.forEach { it.fadeIn() }
            }
        }.start()
    }

    private fun build(ctx: Context, w: Int, h: Int, amount: Int): Bitmap? {
        val wm = WallpaperManager.getInstance(ctx)
        var d: Drawable? = try { wm.drawable } catch (e: Throwable) { null }
        if (d == null) d = try { wm.peekDrawable() } catch (e: Throwable) { null }
        if (d == null) d = try {
            wm.getWallpaperFile(WallpaperManager.FLAG_SYSTEM)?.use { fd ->
                val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                BitmapFactory.decodeFileDescriptor(fd.fileDescriptor, null, o)?.let { android.graphics.drawable.BitmapDrawable(ctx.resources, it) }
            }
        } catch (e: Throwable) { null }
        if (d == null) return null
        val bw = max(16, w / 6); val bh = max(16, h / 6)
        val out = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val iw = if (d.intrinsicWidth > 0) d.intrinsicWidth else bw
        val ih = if (d.intrinsicHeight > 0) d.intrinsicHeight else bh
        val s = max(bw.toFloat() / iw, bh.toFloat() / ih)
        c.translate((bw - iw * s) / 2f, (bh - ih * s) / 2f); c.scale(s, s)
        d.setBounds(0, 0, iw, ih); d.draw(c)
        val px = IntArray(bw * bh); out.getPixels(px, 0, bw, 0, 0, bw, bh)
        val r = amount.coerceIn(1, 20)
        var a = px; var cw = bw; var ch = bh
        repeat(2) {
            val t = IntArray(a.size); blurH(a, t, cw, ch, r)
            val tr = IntArray(a.size); transpose(t, tr, cw, ch)
            a = tr; val sw = cw; cw = ch; ch = sw
        }
        // after 2 iterations (each transposes) orientation is back to normal
        out.setPixels(a, 0, bw, 0, 0, bw, bh)
        return out
    }

    private fun transpose(s: IntArray, d: IntArray, w: Int, h: Int) {
        for (y in 0 until h) for (x in 0 until w) d[x * h + y] = s[y * w + x]
    }

    private fun blurH(s: IntArray, d: IntArray, w: Int, h: Int, r: Int) {
        val n = 2 * r + 1
        for (y in 0 until h) {
            val row = y * w
            var a = 0; var rr = 0; var g = 0; var b = 0
            for (i in -r..r) { val p = s[row + i.coerceIn(0, w - 1)]; a += p ushr 24; rr += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255 }
            for (x in 0 until w) {
                d[row + x] = ((a / n) shl 24) or ((rr / n) shl 16) or ((g / n) shl 8) or (b / n)
                val ad = s[row + (x + r + 1).coerceAtMost(w - 1)]; val rm = s[row + (x - r).coerceAtLeast(0)]
                a += (ad ushr 24) - (rm ushr 24); rr += ((ad shr 16) and 255) - ((rm shr 16) and 255)
                g += ((ad shr 8) and 255) - ((rm shr 8) and 255); b += (ad and 255) - (rm and 255)
            }
        }
    }
}

/** Rounded frosted-glass panel: blurred wallpaper slice + tint + hairline stroke. */
class FrostView(ctx: Context, val home: HomeView) : View(ctx) {
    var radius = 0f
    var tint = 0x40FFFFFF
    var stroke = 0x33FFFFFF
    var useBmp = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val dst = RectF()
    var blurA = 1f
    fun fadeIn() { anim(0f, 1f, 520, Anim.out) { blurA = it; invalidate() } }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); Frost.views.add(this) }
    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); Frost.views.remove(this) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val b = Frost.bmp
        c.save()
        if (radius > 0f) { path.reset(); path.addRoundRect(0f, 0f, w, h, radius, radius, Path.Direction.CW); c.clipPath(path) }
        if (useBmp && b != null && !b.isRecycled) {
            val r = home.rectOf(this)
            c.translate(-r.left, -r.top)
            dst.set(0f, 0f, home.width.toFloat(), home.height.toFloat())
            p.alpha = (blurA * 255).toInt().coerceIn(0, 255)
            c.drawBitmap(b, null, dst, p)
            p.alpha = 255
            c.translate(r.left, r.top)
        }
        c.drawColor(tint)
        c.restore()
        if (radius > 0f && stroke != 0) {
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(1f); p.color = stroke
            c.drawRoundRect(dp(0.5f), dp(0.5f), w - dp(0.5f), h - dp(0.5f), radius, radius, p)
            p.style = Paint.Style.FILL
        }
    }
}

class MenuDef(val icon: Int, val label: String, val danger: Boolean = false, val action: () -> Unit)

/** Refined popup menu with outline (SVG-style) icons. */
object Pop {
    fun show(act: Activity, dark: Boolean, x: Float, aTop: Float, aBottom: Float, items: List<MenuDef>) {
        val d = act.resources.displayMetrics.density
        val bg = if (dark) 0xF2212329.toInt() else 0xF7FFFFFF.toInt()
        val fg = if (dark) 0xFFF2F3F7.toInt() else 0xFF1C1E24.toInt()
        val red = 0xFFE5484D.toInt()
        val card = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(bg); cornerRadius = 22 * d; setStroke((1 * d).toInt(), if (dark) 0x22FFFFFF else 0x14000000) }
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            elevation = 14 * d
        }
        val wrap = FrameLayout(act).apply { setPadding((18 * d).toInt(), (14 * d).toInt(), (18 * d).toInt(), (22 * d).toInt()); clipChildren = false; clipToPadding = false }
        wrap.addView(card)
        val pw = PopupWindow(wrap, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.setBackgroundDrawable(ColorDrawable(0)); pw.isOutsideTouchable = true
        items.forEachIndexed { i, m ->
            val col = if (m.danger) red else fg
            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                minimumWidth = (200 * d).toInt()
                setPadding((14 * d).toInt(), (13 * d).toInt(), (18 * d).toInt(), (13 * d).toInt())
                background = RippleDrawable(ColorStateList.valueOf(if (dark) 0x33FFFFFF else 0x1F000000), null, GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 16 * d })
                isClickable = true
                setOnClickListener { wrap.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(Anim.d(130)).setInterpolator(Anim.inOut).withEndAction { pw.dismiss(); m.action() }.start() }
            }
            val iv = ImageView(act).apply { setImageResource(m.icon); imageTintList = ColorStateList.valueOf(col) }
            row.addView(iv, LinearLayout.LayoutParams((22 * d).toInt(), (22 * d).toInt()))
            row.addView(TextView(act).apply { text = m.label; textSize = 15f; setTextColor(col); setPadding((14 * d).toInt(), 0, 0, 0) })
            card.addView(row)
        }
        wrap.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val w = wrap.measuredWidth; val h = wrap.measuredHeight
        val sw = act.resources.displayMetrics.widthPixels; val sh = act.resources.displayMetrics.heightPixels
        val m = (6 * d).toInt()
        val px = (x - w / 2f).toInt().coerceIn(m, max(m, sw - w - m))
        val below = (aBottom - 12 * d).toInt()
        val above = (aTop - h + 12 * d).toInt()
        val below2 = below + h > sh - m
        val py = if (below2) above.coerceAtLeast(m) else below
        pw.showAtLocation(act.window.decorView, Gravity.NO_GRAVITY, px, py)
        wrap.pivotX = (x - px).coerceIn(0f, w.toFloat()); wrap.pivotY = if (below2) h.toFloat() else 0f
        wrap.scaleX = 0.82f; wrap.scaleY = 0.82f; wrap.alpha = 0f
        wrap.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(Anim.d(220)).setInterpolator(Anim.pop).start()
    }
}
