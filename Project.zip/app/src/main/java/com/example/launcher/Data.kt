package com.example.launcher

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.content.res.Resources
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.*
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class App(val pkg: String, val cls: String, val label: String) { val key get() = "$pkg/$cls" }

object Apps {
    var list: List<App> = emptyList()
    var keys: Set<String> = emptySet()
    fun load(ctx: Context) {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        list = pm.queryIntentActivities(i, 0)
            .map { App(it.activityInfo.packageName, it.activityInfo.name, it.loadLabel(pm).toString()) }
            .filter { it.pkg != ctx.packageName }
            .sortedBy { it.label.lowercase() }
        keys = list.map { it.key }.toSet()
    }
}

class IconPack(val pkg: String, val res: Resources) {
    val map = HashMap<String, String>()
    val backs = ArrayList<String>()
    var upon: String? = null
    var scale = 1f
    fun drawable(name: String): Drawable? {
        var id = res.getIdentifier(name, "drawable", pkg)
        if (id == 0) id = res.getIdentifier(name, "mipmap", pkg)
        if (id == 0) return null
        return try { res.getDrawable(id, null) } catch (e: Exception) { null }
    }
    fun drawableFor(p: String, c: String): Drawable? = map["$p/$c"]?.let { drawable(it) }
    fun back(h: Int): Drawable? = if (backs.isEmpty()) null else drawable(backs[abs(h) % backs.size])

    companion object {
        fun load(ctx: Context, pkg: String): IconPack? = try {
            val res = ctx.packageManager.getResourcesForApplication(pkg)
            val ip = IconPack(pkg, res)
            val id = res.getIdentifier("appfilter", "xml", pkg)
            val xp: XmlPullParser = if (id != 0) res.getXml(id) else {
                val x = Xml.newPullParser(); x.setInput(res.assets.open("appfilter.xml"), null); x
            }
            val rx = Regex("ComponentInfo\\{([^/]+)/([^}]+)\\}")
            var ev = xp.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) when (xp.name) {
                    "item" -> {
                        val comp = xp.getAttributeValue(null, "component"); val dr = xp.getAttributeValue(null, "drawable")
                        val m = if (comp != null && dr != null) rx.find(comp) else null
                        if (m != null) {
                            val p = m.groupValues[1]; var cl = m.groupValues[2]
                            if (cl.startsWith(".")) cl = p + cl
                            ip.map["$p/$cl"] = dr!!
                        }
                    }
                    "iconback" -> for (i in 0 until xp.attributeCount) if (xp.getAttributeName(i).startsWith("img")) ip.backs.add(xp.getAttributeValue(i))
                    "iconupon" -> ip.upon = xp.getAttributeValue(null, "img1")
                    "scale" -> xp.getAttributeValue(null, "factor")?.toFloatOrNull()?.let { ip.scale = it }
                }
                ev = xp.next()
            }
            ip
        } catch (e: Exception) { null }

        /** installed icon packs as (package, label) */
        fun find(ctx: Context): List<Pair<String, String>> {
            val pm = ctx.packageManager
            val out = LinkedHashMap<String, String>()
            val intents = listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.fede.launcher.THEME_ICONPACK",
                "com.gau.go.launcherex.theme").map { Intent(it) } +
                Intent(Intent.ACTION_MAIN).addCategory("com.anddoes.launcher.THEME")
            for (i in intents) try {
                for (r in pm.queryIntentActivities(i, 0)) out[r.activityInfo.packageName] = r.loadLabel(pm).toString()
            } catch (e: Exception) {}
            return out.map { Pair(it.key, it.value) }.sortedBy { it.second.lowercase() }
        }
    }
}

object Icons {
    private val cache = ConcurrentHashMap<String, Bitmap>()
    var shape = 0
    private var packPkg = ""
    private var pack: IconPack? = null

    fun configure(ctx: Context, s: Int, pk: String) {
        if (s == shape && pk == packPkg && (pk.isEmpty() || pack != null)) return
        shape = s; packPkg = pk
        pack = if (pk.isEmpty()) null else IconPack.load(ctx, pk)
        cache.clear()
    }

    fun get(ctx: Context, pkg: String, cls: String, size: Int): Bitmap? {
        val k = "$pkg/$cls@$size#$shape#$packPkg"
        cache[k]?.let { return it }
        val b = make(ctx, pkg, cls, size) ?: return null
        cache[k] = b
        return b
    }

    private fun make(ctx: Context, pkg: String, cls: String, size: Int): Bitmap? {
        val d = try { ctx.packageManager.getActivityIcon(ComponentName(pkg, cls)) } catch (e: Exception) { return null }
        val s = size.toFloat()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val pk = pack
        // 1) icon pack has a dedicated icon -> use it as-is
        pk?.drawableFor(pkg, cls)?.let { it.setBounds(0, 0, size, size); it.draw(c); return bmp }
        val layer = c.saveLayer(0f, 0f, s, s, null)
        val packed = pk != null && pk.backs.isNotEmpty()
        if (packed) {
            // 2) pack without a mapping -> compose on the pack's background
            pk!!.back(pkg.hashCode())?.let { it.setBounds(0, 0, size, size); it.draw(c) }
            val fg: Drawable = if (d is AdaptiveIconDrawable) (d.foreground ?: d) else d
            val l = size * pk.scale * (if (d is AdaptiveIconDrawable) 1f else 0.7f)
            val o = ((size - l) / 2f).toInt(); val e = (o + l).toInt()
            fg.setBounds(o, o, e, e); fg.draw(c)
            pk.upon?.let { pk.drawable(it) }?.let { it.setBounds(0, 0, size, size); it.draw(c) }
        } else if (d is AdaptiveIconDrawable) {
            val o = (s * 0.25f).toInt()
            d.background?.let { it.setBounds(-o, -o, size + o, size + o); it.draw(c) }
            d.foreground?.let { it.setBounds(-o, -o, size + o, size + o); it.draw(c) }
        } else {
            legacy(c, d, size)
        }
        if (!packed) {
            val m = Paint(Paint.ANTI_ALIAS_FLAG)
            m.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            c.drawPath(path(s), m)
        }
        c.restoreToCount(layer)
        return bmp
    }

    /** Legacy (non-adaptive) icon: crop to its artwork; if it has its own plate fill the shape with it, else put the glyph on a plate. */
    private fun legacy(c: Canvas, d: Drawable, size: Int) {
        val src = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, size, size); d.draw(Canvas(src))
        val px = IntArray(size * size); src.getPixels(px, 0, size, 0, 0, size, size)
        var x0 = size; var y0 = size; var x1 = -1; var y1 = -1; var n = 0
        var r = 0L; var g = 0L; var b = 0L
        for (y in 0 until size) for (x in 0 until size) {
            val p = px[y * size + x]
            if ((p ushr 24) > 24) {
                n++; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
                r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255
            }
        }
        val s = size.toFloat(); val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (n == 0) { c.drawBitmap(src, 0f, 0f, paint); return }
        val bw = x1 - x0 + 1; val bh = y1 - y0 + 1
        val crop = Rect(x0, y0, x1 + 1, y1 + 1)
        val fill = n.toFloat() / (bw * bh)
        if (fill > 0.72f) {
            c.drawBitmap(src, crop, RectF(0f, 0f, s, s), paint)   // has its own plate -> fill the shape
        } else {
            val lum = (0.299 * r + 0.587 * g + 0.114 * b) / n / 255.0
            c.drawColor(if (lum > 0.6) 0xFF2B2E36.toInt() else 0xFFF2F3F7.toInt())
            val box = s * 0.64f; val k = min(box / bw, box / bh)
            val w = bw * k; val h = bh * k
            c.drawBitmap(src, crop, RectF((s - w) / 2, (s - h) / 2, (s + w) / 2, (s + h) / 2), paint)
        }
    }

    // 0 circle, 1 squircle, 2 rounded square, 3 square
    private fun path(s: Float): Path {
        val p = Path()
        when (shape) {
            1 -> {
                val n = 72
                for (i in 0..n) {
                    val t = 2 * PI * i / n
                    val ct = cos(t); val st = sin(t)
                    val x = s / 2 + s / 2 * sign(ct).toFloat() * abs(ct).pow(0.45).toFloat()
                    val y = s / 2 + s / 2 * sign(st).toFloat() * abs(st).pow(0.45).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
            2 -> p.addRoundRect(0f, 0f, s, s, s * 0.3f, s * 0.3f, Path.Direction.CW)
            3 -> p.addRoundRect(0f, 0f, s, s, s * 0.06f, s * 0.06f, Path.Direction.CW)
            else -> p.addCircle(s / 2, s / 2, s / 2, Path.Direction.CW)
        }
        return p
    }
}

class Prefs(ctx: Context) {
    val sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    private fun int(k: String, d: Int) = object : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) { sp.edit().putInt(k, value).apply() }
    }
    private fun bool(k: String, d: Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) { sp.edit().putBoolean(k, value).apply() }
    }
    var cols by int("cols", 0)
    var rows by int("rows", 0)
    var iconScale by int("iconScale", 100)
    var labelSize by int("labelSize", 12)
    var shape by int("shape2", 0)
    var frost by int("frost", 35)
    var animPct by int("animPct", 100)
    var labels by bool("labels", true)
    var darkLabels by bool("darkLabels", false)
    var indicator by bool("indicator", true)
    var searchPill by bool("searchPill", true)
    var standard by bool("standard", true)
    var lock by bool("lock", false)
    var dirty by bool("dirty", false)
    var blur by bool("blur", true)
    var folderBgOn by bool("folderBgOn", true)
    var folderColor by int("folderColor", 0)
    var folderOpacity by int("folderOpacity", 35)
    var folderRadius by int("folderRadius", 30)
    var folderOutline by bool("folderOutline", false)
    var folderBlur by bool("folderBlur", true)
    var folderLabels by bool("folderLabels", true)
    var folderIconScale by int("folderIconScale", 100)
    var folderGrid by int("folderGrid", 0)
    var fpColor by int("fpColor", 0)
    var fpOpacity by int("fpOpacity", 40)
    var fpRadius by int("fpRadius", 36)
    var fpOutline by bool("fpOutline", true)
    var fpBlur by bool("fpBlur", true)
    var fpCols by int("fpCols", 0)
    var folderDim by int("folderDim", 40)
    var fpStyle by int("fpStyle", 0)
    var fpAdd by bool("fpAdd", true)
    var fpIconScale by int("fpIconScale", 115)
    var dockHeight by int("dockHeight", 88)
    var dockMargin by int("dockMargin", 12)
    var dockIconScale by int("dockIconScale", 100)
    var dockOpacity by int("dockOpacity", 35)
    var dockRadius by int("dockRadius", 34)
    var dockColor by int("dockColor", 0)
    var dockOutline by bool("dockOutline", false)
    var dockBgOn by bool("dockBgOn", true)
    var dockBlur by bool("dockBlur", true)
    var dockLabels by bool("dockLabels", false)
    var dockFull by bool("dockFull", false)
    var dockMax by int("dockMax", 0)
    var recentsMax by int("recentsMax", 4)
    var askedAccess by bool("askedAccess", false)
    var recentsDock by bool("recentsDock", true)
    var recents: String
        get() = sp.getString("recents", "") ?: ""
        set(v) { sp.edit().putString("recents", v).apply() }
    var blurAmt by int("blurAmt", 6)
    var popupDark by bool("popupDark", false)
    var drawerCols by int("drawerCols", 0)
    var iconPack: String
        get() = sp.getString("iconPack", "") ?: ""
        set(v) { sp.edit().putString("iconPack", v).apply() }
}

class Item(
    var id: Long, val isFolder: Boolean, var pkg: String = "", var cls: String = "", var label: String = "",
    var page: Int = 0, var x: Int = 0, var y: Int = 0, var sx: Int = 1, var sy: Int = 1
) {
    val kids = ArrayList<Item>()
    var widgetId = -1
    val isWidget get() = widgetId >= 0
    val key get() = "$pkg/$cls"
}

class Model(ctx: Context) {
    private val sp = ctx.getSharedPreferences("layout", Context.MODE_PRIVATE)
    var items = ArrayList<Item>()
    var cols = 4; var rows = 5; var dockCols = 4
    private var nextId = 1L
    private var seeded = false
    fun newId() = nextId++

    fun bounds(page: Int) = if (page == -1) Pair(dockCols, 1) else Pair(cols, rows)
    fun freeIn(list: List<Item>, page: Int, x: Int, y: Int, sx: Int, sy: Int, ignore: Item? = null): Boolean {
        val (c, r) = bounds(page)
        if (x < 0 || y < 0 || x + sx > c || y + sy > r) return false
        return list.none { it !== ignore && it.page == page && x < it.x + it.sx && x + sx > it.x && y < it.y + it.sy && y + sy > it.y }
    }
    fun isFree(page: Int, x: Int, y: Int, sx: Int, sy: Int, ignore: Item?) = freeIn(items, page, x, y, sx, sy, ignore)
    fun itemAt(page: Int, x: Int, y: Int, ignore: Item?) =
        items.firstOrNull { it !== ignore && it.page == page && x >= it.x && x < it.x + it.sx && y >= it.y && y < it.y + it.sy }
    fun nearest(page: Int, x: Int, y: Int, sx: Int, sy: Int, ignore: Item?): Pair<Int, Int>? {
        val (c, r) = bounds(page)
        var best: Pair<Int, Int>? = null; var bd = Int.MAX_VALUE
        for (yy in 0..(r - sy)) for (xx in 0..(c - sx)) if (isFree(page, xx, yy, sx, sy, ignore)) {
            val d = (xx - x) * (xx - x) + (yy - y) * (yy - y)
            if (d < bd) { bd = d; best = Pair(xx, yy) }
        }
        return best
    }
    fun spot(among: List<Item>, sx: Int, sy: Int): Triple<Int, Int, Int> {
        var pg = 0
        while (true) {
            for (yy in 0..(rows - sy)) for (xx in 0..(cols - sx)) if (freeIn(among, pg, xx, yy, sx, sy)) return Triple(pg, xx, yy)
            pg++
        }
    }
    fun fit() {
        val placed = ArrayList<Item>()
        for (i in items.sortedWith(compareBy<Item>({ it.page }, { it.y }, { it.x }))) {
            val (c, r) = bounds(i.page)
            if (i.page == -1) { i.sx = 1; i.sy = 1 } else { i.sx = min(i.sx, c); i.sy = min(i.sy, r) }
            if (freeIn(placed, i.page, i.x, i.y, i.sx, i.sy)) { placed.add(i); continue }
            if (i.page == -1) {
                val s = (0 until dockCols).firstOrNull { freeIn(placed, -1, it, 0, 1, 1) }
                if (s != null) { i.x = s; i.y = 0; placed.add(i); continue }
            }
            val (pg, x, y) = spot(placed, i.sx, i.sy); i.page = pg; i.x = x; i.y = y; placed.add(i)
        }
        val dk = placed.filter { it.page == -1 }.sortedBy { it.x }
        dk.forEachIndexed { n, d -> d.x = n }
        items = placed
    }
    fun sync(standard: Boolean, ctx: Context) {
        val it = items.iterator()
        while (it.hasNext()) {
            val i = it.next()
            if (i.isFolder) { i.kids.removeAll { k -> k.key !in Apps.keys }; if (i.kids.isEmpty()) it.remove() }
            else if (i.isWidget) { if (AppWidgetManager.getInstance(ctx).getAppWidgetInfo(i.widgetId) == null) it.remove() }
            else if (i.key !in Apps.keys) it.remove()
        }
        if (!seeded) seed(ctx)
        if (standard) {
            val present = HashSet<String>()
            items.forEach { if (it.isFolder) it.kids.forEach { k -> present.add(k.key) } else present.add(it.key) }
            for (a in Apps.list) if (a.key !in present) {
                val n = Item(newId(), false, a.pkg, a.cls, a.label)
                val (pg, x, y) = spot(items, 1, 1); n.page = pg; n.x = x; n.y = y; items.add(n)
            }
        }
    }
    private fun seed(ctx: Context) {
        seeded = true
        val pm = ctx.packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        var slot = 0
        for (intent in intents) {
            val ri = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) ?: continue
            val pkg = ri.activityInfo.packageName
            val app = Apps.list.firstOrNull { it.pkg == pkg } ?: continue
            if (items.any { !it.isFolder && it.pkg == pkg } || slot >= dockCols) continue
            items.add(Item(newId(), false, app.pkg, app.cls, app.label, -1, slot++, 0))
        }
    }

    private fun toJson(i: Item): JSONObject = JSONObject().apply {
        put("id", i.id); put("f", i.isFolder); put("p", i.pkg); put("c", i.cls); put("l", i.label)
        put("pg", i.page); put("x", i.x); put("y", i.y); put("sx", i.sx); put("sy", i.sy)
        if (i.isWidget) put("w", i.widgetId)
        if (i.isFolder) put("k", JSONArray().also { a -> i.kids.forEach { a.put(toJson(it)) } })
    }
    private fun fromJson(o: JSONObject): Item =
        Item(o.getLong("id"), o.getBoolean("f"), o.getString("p"), o.getString("c"), o.getString("l"),
            o.getInt("pg"), o.getInt("x"), o.getInt("y"), o.getInt("sx"), o.getInt("sy")).also { i ->
            i.widgetId = o.optInt("w", -1)
            o.optJSONArray("k")?.let { a -> for (n in 0 until a.length()) i.kids.add(fromJson(a.getJSONObject(n))) }
        }
    fun load() {
        items = ArrayList()
        try {
            val a = JSONArray(sp.getString("items", "[]"))
            for (n in 0 until a.length()) items.add(fromJson(a.getJSONObject(n)))
        } catch (e: Exception) { items = ArrayList() }
        nextId = sp.getLong("nid", 1L); seeded = sp.getBoolean("seeded", false)
    }
    fun save() {
        sp.edit().putString("items", JSONArray().also { a -> items.forEach { a.put(toJson(it)) } }.toString())
            .putLong("nid", nextId).putBoolean("seeded", seeded).apply()
    }
}
