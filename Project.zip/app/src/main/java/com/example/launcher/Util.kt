package com.example.launcher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.animation.Interpolator
import android.view.animation.PathInterpolator

object Anim {
    var scale = 1f
    var speed = 1f
    var out: Interpolator = PathInterpolator(0.22f, 1f, 0.36f, 1f)
    var inOut: Interpolator = PathInterpolator(0.4f, 0f, 0.2f, 1f)
    val pop: Interpolator = PathInterpolator(0.34f, 1.45f, 0.64f, 1f)
    fun d(ms: Long) = (ms * scale * speed).toLong()

    /** 0 = snappy, 1 = smooth (default), 2 = soft & floaty */
    fun setStyle(s: Int) {
        when (s) {
            0 -> { out = PathInterpolator(0.16f, 1f, 0.3f, 1f); inOut = PathInterpolator(0.3f, 0f, 0.1f, 1f); speed = 0.8f }
            2 -> { out = PathInterpolator(0.25f, 0.1f, 0.25f, 1f); inOut = PathInterpolator(0.45f, 0f, 0.25f, 1f); speed = 1.3f }
            else -> { out = PathInterpolator(0.22f, 1f, 0.36f, 1f); inOut = PathInterpolator(0.4f, 0f, 0.2f, 1f); speed = 1f }
        }
    }
}

fun Context.dp(v: Float) = v * resources.displayMetrics.density
fun Context.dpi(v: Float) = dp(v).toInt()
fun View.dp(v: Float) = context.dp(v)
fun View.dpi(v: Float) = context.dp(v).toInt()
fun rounded(color: Int, r: Float) = GradientDrawable().apply { setColor(color); cornerRadius = r }

fun anim(from: Float, to: Float, ms: Long, ip: Interpolator = Anim.out, end: (() -> Unit)? = null, f: (Float) -> Unit): ValueAnimator {
    val a = ValueAnimator.ofFloat(from, to)
    a.duration = Anim.d(ms); a.interpolator = ip
    a.addUpdateListener { f(it.animatedValue as Float) }
    a.addListener(object : AnimatorListenerAdapter() {
        var cancelled = false
        override fun onAnimationCancel(an: Animator) { cancelled = true }
        override fun onAnimationEnd(an: Animator) { if (!cancelled) end?.invoke() }
    })
    a.start(); return a
}
