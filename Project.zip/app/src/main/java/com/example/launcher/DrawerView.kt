package com.example.launcher

import android.content.Context
import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class DrawerView(ctx: Context, val home: HomeView) : LinearLayout(ctx) {
    val search = EditText(ctx)
    val rv = RecyclerView(ctx)
    private var shown: List<App> = emptyList()
    private var cellH = 200
    private var insT = 0; private var insB = 0
    private var y0 = 0f; private var x0 = 0f; private var mode = 0
    private var vt: VelocityTracker? = null
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    class VH(val v: CellView) : RecyclerView.ViewHolder(v)

    val adapter = object : RecyclerView.Adapter<VH>() {
        override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
            val v = CellView(p.context, Item(0, false), home)
            v.alwaysLabel = true
            v.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, cellH)
            return VH(v)
        }
        override fun getItemCount() = shown.size
        override fun onBindViewHolder(h: VH, i: Int) {
            val a = shown[i]; val v = h.v
            v.item = Item(0, false, a.pkg, a.cls, a.label); v.invalidate()
            v.setOnClickListener { home.launch(a.pkg, a.cls, v) }
            v.setOnLongClickListener { home.beginDragFromDrawer(a) }
        }
    }

    init {
        orientation = VERTICAL
        search.apply {
            hint = "Search apps"; setHintTextColor(0x99FFFFFF.toInt()); setTextColor(Color.WHITE); textSize = 16f
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = rounded(0x33FFFFFF, dp(26f)); setPadding(dpi(20f), 0, dpi(20f), 0)
        }
        addView(search, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpi(52f)).apply { bottomMargin = dpi(6f) })
        rv.layoutManager = GridLayoutManager(ctx, 4)
        rv.adapter = adapter; rv.itemAnimator = null; rv.setHasFixedSize(true); rv.overScrollMode = OVER_SCROLL_NEVER; rv.clipToPadding = false
        addView(rv, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filter(s?.toString().orEmpty()) }
        })
        search.setOnEditorActionListener { _, _, _ -> shown.firstOrNull()?.let { home.launch(it.pkg, it.cls, null) }; true }
    }

    fun setInsets(t: Int, b: Int) { insT = t; insB = b }

    fun refresh() {
        val px = if (home.width > dp(600f)) dpi(40f) else dpi(14f)
        setPadding(px, insT + dpi(16f), px, 0)
        rv.setPadding(0, dpi(10f), 0, insB + dpi(24f))
        (rv.layoutManager as GridLayoutManager).spanCount = if (home.prefs.drawerCols > 0) home.prefs.drawerCols else max(4, min(home.cols, 10))
        cellH = (home.iconPx + home.labelPx * 2 + dp(30f)).toInt()
        filter(search.text.toString())
        requestLayout(); rv.post { adapter.notifyDataSetChanged() }
    }

    private fun filter(q: String) {
        shown = if (q.isBlank()) Apps.list else Apps.list.filter { it.label.contains(q.trim(), true) }
        adapter.notifyDataSetChanged()
    }

    fun clear() { search.setText(""); search.clearFocus(); rv.scrollToPosition(0) }
    fun openKeyboard() {
        search.requestFocus()
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, 0)
    }
    fun hideKb() {
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(windowToken, 0)
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { y0 = e.y; x0 = e.x; mode = 0; vt?.recycle(); vt = VelocityTracker.obtain(); vt!!.addMovement(e) }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                val dy = e.y - y0
                if (mode == 0 && dy > slop && abs(e.x - x0) < dy && !rv.canScrollVertically(-1)) { mode = 1; hideKb() }
            }
        }
        return mode == 1
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        vt?.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> if (mode == 1) home.setDrawer(1f - (e.y - y0 - slop) / (height * 0.55f))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode == 1) {
                    vt?.computeCurrentVelocity(1000)
                    if (home.drawerP < 0.7f || (vt?.yVelocity ?: 0f) > 1200f) home.closeDrawer() else home.openDrawer(false)
                }
                mode = 0
            }
        }
        return true
    }
}
