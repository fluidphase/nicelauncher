package com.example.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

class CellView(ctx: Context, var item: Item, val home: HomeView) : View(ctx) {
    var dock = false
    var alwaysLabel = false
    var resizing = false
    var downX = 0f
    var downY = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rf = RectF()
    private val dst = RectF()

    private fun showLabel() = alwaysLabel || (home.prefs.labels && !dock)
    private fun setupText() {
        tp.textSize = home.labelPx; tp.color = home.labelColor
        if (home.prefs.darkLabels) tp.clearShadowLayer() else tp.setShadowLayer(dp(2f), 0f, dp(1f), 0x66000000)
    }
    private fun labelH(): Float = if (showLabel()) { setupText(); tp.fontSpacing + dp(4f) } else 0f
    private fun isBig() = item.isFolder && (item.sx > 1 || item.sy > 1)

    fun bounds(out: RectF): RectF {
        val w = width.toFloat(); val h = height.toFloat(); val lh = labelH()
        if (isBig()) { val m = dp(4f); out.set(m, m, w - m, h - lh - m * 0.5f) }
        else {
            val ic = if (dock) min(home.iconPx.toFloat(), h - dp(22f)) else home.iconPx.toFloat()
            val top = (h - ic - lh) / 2f
            out.set((w - ic) / 2f, top, (w + ic) / 2f, top + ic)
        }
        return out
    }

    private fun gridDims() = Pair((item.sx * 3 + 1) / 2, (item.sy * 3 + 1) / 2)

    private fun slot(b: RectF, idx: Int, out: RectF): RectF {
        val (gc, gr) = gridDims()
        val pad = dp(12f)
        val cw = (b.width() - 2 * pad) / gc; val ch = (b.height() - 2 * pad) / gr
        val s = min(min(cw, ch) * 0.84f, home.iconPx * 1.05f)
        val cx = b.left + pad + cw * (idx % gc + 0.5f); val cy = b.top + pad + ch * (idx / gc + 0.5f)
        out.set(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2); return out
    }

    private fun bigCount() = gridDims().let { min(it.first * it.second, item.kids.size) }

    fun kidAt(x: Float, y: Float): Item? {
        if (!isBig()) return null
        val b = bounds(RectF()); val r = RectF()
        for (i in 0 until bigCount()) {
            slot(b, i, r); r.inset(-dp(4f), -dp(4f))
            if (r.contains(x, y)) return item.kids[i]
        }
        return null
    }

    private fun bmp(i: Item) = Icons.get(context, i.pkg, i.cls, home.bmpPx)

    override fun onDraw(c: Canvas) {
        val b = bounds(rf)
        p.style = Paint.Style.FILL; p.color = Color.WHITE
        if (!item.isFolder) {
            bmp(item)?.let { c.drawBitmap(it, null, b, p) }
        } else {
            p.color = home.frostColor
            val r = if (isBig()) min(dp(30f), b.height() * 0.22f) else b.width() * 0.3f
            c.drawRoundRect(b, r, r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(1f); p.color = 0x40FFFFFF; c.drawRoundRect(b, r, r, p); p.style = Paint.Style.FILL
            p.color = Color.WHITE
            if (isBig()) {
                val t = RectF()
                for (i in 0 until bigCount()) bmp(item.kids[i])?.let { c.drawBitmap(it, null, slot(b, i, t), p) }
            } else {
                val n = item.kids.size; val g = if (n <= 4) 2 else 3
                val pad = b.width() * 0.1f; val s = (b.width() - pad * 2) / g; val ins = s * 0.08f
                for (i in 0 until min(n, g * g)) {
                    dst.set(b.left + pad + (i % g) * s + ins, b.top + pad + (i / g) * s + ins,
                        b.left + pad + (i % g + 1) * s - ins, b.top + pad + (i / g + 1) * s - ins)
                    bmp(item.kids[i])?.let { c.drawBitmap(it, null, dst, p) }
                }
            }
        }
        if (showLabel()) {
            setupText()
            val t = TextUtils.ellipsize(item.label, tp, width - dp(6f), TextUtils.TruncateAt.END)
            c.drawText(t, 0, t.length, width / 2f, b.bottom + dp(4f) - tp.fontMetrics.ascent, tp)
        }
        if (resizing) {
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(2f); p.color = 0xEEFFFFFF.toInt()
            val o = RectF(b); o.inset(-dp(2f), -dp(2f))
            c.drawRoundRect(o, dp(30f), dp(30f), p)
            p.style = Paint.Style.FILL
            p.color = 0xFF3D7BFF.toInt(); c.drawCircle(b.right, b.bottom, dp(15f), p)
            p.color = Color.WHITE; c.drawCircle(b.right, b.bottom, dp(10f), p)
            p.color = 0xFF3D7BFF.toInt(); c.drawCircle(b.right, b.bottom, dp(4f), p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y
                animate().scaleX(0.92f).scaleY(0.92f).setDuration(Anim.d(110)).setInterpolator(Anim.out).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(Anim.d(320)).setInterpolator(Anim.pop).start()
        }
        return super.onTouchEvent(e)
    }
}

class CellLayout(ctx: Context, val home: HomeView) : ViewGroup(ctx) {
    var cols = 4; var rows = 5; var padX = 0f; var dockMode = false; var page = 0
    private val anims = HashMap<Item, ValueAnimator>()
    private val cur = HashMap<Item, RectF>()
    init { clipChildren = false; clipToPadding = false }

    val cellW get() = (width - 2 * padX) / cols
    val cellH get() = height.toFloat() / rows
    fun target(i: Item) = RectF(padX + i.x * cellW, i.y * cellH, padX + (i.x + i.sx) * cellW, (i.y + i.sy) * cellH)

    fun rebuild(list: List<Item>) {
        anims.values.forEach { it.cancel() }; anims.clear(); cur.clear(); removeAllViews()
        for (i in list) {
            val v = CellView(context, i, home); v.dock = dockMode
            v.setOnClickListener { home.onItemClick(v) }
            v.setOnLongClickListener { home.onItemLong(v) }
            addView(v)
        }
    }

    override fun onMeasure(wm: Int, hm: Int) = setMeasuredDimension(MeasureSpec.getSize(wm), MeasureSpec.getSize(hm))
    override fun onLayout(c: Boolean, l: Int, t: Int, r: Int, b: Int) { for (n in 0 until childCount) place(getChildAt(n) as CellView) }

    private fun place(v: CellView) {
        val rc = cur[v.item] ?: target(v.item)
        val w = rc.width().roundToInt(); val h = rc.height().roundToInt()
        val l = rc.left.roundToInt(); val t = rc.top.roundToInt()
        v.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
        v.layout(l, t, l + w, t + h)
    }

    fun moveTo(item: Item) {
        val v = (0 until childCount).map { getChildAt(it) as CellView }.firstOrNull { it.item === item } ?: return
        val from = RectF(cur[item] ?: RectF(v.left.toFloat(), v.top.toFloat(), v.right.toFloat(), v.bottom.toFloat()))
        val to = target(item)
        anims[item]?.cancel()
        anims[item] = anim(0f, 1f, 320, Anim.out, end = { cur.remove(item); anims.remove(item); place(v) }) { t ->
            fun lerp(a: Float, b: Float) = a + (b - a) * t
            cur[item] = RectF(lerp(from.left, to.left), lerp(from.top, to.top), lerp(from.right, to.right), lerp(from.bottom, to.bottom))
            place(v)
        }
    }
}

class DotsView(ctx: Context) : View(ctx) {
    var count = 1; var pos = 0f; var dark = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val r = dp(3f); val gap = dp(8f); val extra = dp(10f)
        val total = count * 2 * r + (count - 1) * gap + extra
        var x = (width - total) / 2f; val y = height / 2f
        val base = if (dark) 0 else 255
        for (i in 0 until count) {
            val a = 1f - min(1f, abs(i - pos)); val w = 2 * r + extra * a
            p.color = Color.argb((110 + 145 * a).toInt(), base, base, base)
            c.drawRoundRect(x, y - r, x + w, y + r, r, r, p); x += w + gap
        }
    }
}
