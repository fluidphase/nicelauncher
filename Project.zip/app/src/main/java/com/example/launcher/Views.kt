package com.example.launcher

import android.animation.ValueAnimator
import android.appwidget.AppWidgetHostView
import android.content.Context
import android.os.Bundle
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import kotlin.math.hypot
import android.graphics.*
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

interface Resizable { var resizing: Boolean; fun handleAt(i: Int): PointF }

fun View.cellItem(): Item? = (this as? CellView)?.item ?: (this as? WidgetCell)?.item

/** white outline + pill handles that pop in */
fun drawResizeUi(c: Canvas, v: View, r: Resizable, b: RectF, rad: Float, rz: Float) {
    val p = Paint(Paint.ANTI_ALIAS_FLAG); val a = (rz.coerceIn(0f, 1f) * 255).toInt(); val k = rz.coerceAtLeast(0f)
    val o = RectF(b); o.inset(-v.dp(2f), -v.dp(2f))
    p.style = Paint.Style.STROKE; p.strokeWidth = v.dp(2.5f); p.color = Color.argb(a, 255, 255, 255)
    c.drawRoundRect(o, rad, rad, p)
    val rf = RectF()
    for (i in 0..3) {
        val hp = r.handleAt(i); val vert = i % 2 == 0
        val hw = (if (vert) v.dp(3.5f) else v.dp(12f)) * k; val hh = (if (vert) v.dp(12f) else v.dp(3.5f)) * k
        rf.set(hp.x - hw, hp.y - hh, hp.x + hw, hp.y + hh)
        p.style = Paint.Style.FILL; p.color = Color.argb(a, 255, 255, 255); c.drawRoundRect(rf, v.dp(3.5f) * k, v.dp(3.5f) * k, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = v.dp(0.8f); p.color = Color.argb(a / 4, 0, 0, 0); c.drawRoundRect(rf, v.dp(3.5f) * k, v.dp(3.5f) * k, p)
    }
}

class CellView(ctx: Context, var item: Item, val home: HomeView) : View(ctx), Resizable {
    var dock = false
    var alwaysLabel = false
    var snap: Bitmap? = null
    var iconMul = 1f
    var rz = 0f; private var rzA: ValueAnimator? = null
    override var resizing: Boolean = false
        set(x) { field = x; rzA?.cancel(); rzA = anim(rz, if (x) 1f else 0f, 280, Anim.pop) { rz = it; invalidate() } }
    var downX = 0f
    var downY = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rf = RectF()
    private val dst = RectF()

    private fun showLabel() = alwaysLabel || (if (dock) home.prefs.dockLabels else if (item.isFolder) home.prefs.folderLabels else home.prefs.labels)
    private fun setupText() {
        tp.textSize = home.labelPx; tp.color = home.labelColor
        if (home.prefs.darkLabels) tp.clearShadowLayer() else tp.setShadowLayer(dp(2f), 0f, dp(1f), 0x66000000)
    }
    private fun labelH(): Float = if (showLabel()) { setupText(); tp.fontSpacing + dp(4f) } else 0f
    private fun isBig() = item.isFolder && (item.sx > 1 || item.sy > 1)

    fun bounds(out: RectF): RectF {
        val w = width.toFloat(); val h = height.toFloat()
        if (item.isWidget) { val m = dp(4f); out.set(m, m, w - m, h - m); return out }
        val lh = labelH()
        if (isBig()) { val m = dp(4f); out.set(m, m, w - m, h - lh - m * 0.5f) }
        else {
            val ic = if (dock) min(home.iconPx * home.prefs.dockIconScale / 100f, h - lh - dp(14f)) else home.iconPx * iconMul
            val top = (h - ic - lh) / 2f
            out.set((w - ic) / 2f, top, (w + ic) / 2f, top + ic)
        }
        return out
    }

    private fun fScale() = (home.prefs.folderIconScale / 100f).coerceIn(0.5f, 1.2f)

    private fun fRadius(b: RectF): Float {
        val pct = home.prefs.folderRadius.toFloat(); val m = min(b.width(), b.height())
        return if (isBig()) (min(dp(32f), m * 0.22f) * pct / 30f).coerceAtMost(m / 2f) else b.width() * pct / 100f
    }

    private fun gridOf(b: RectF): IntArray {
        val pad = dp(9f); val s0 = home.iconPx * 0.86f * fScale(); val gap = s0 * 0.14f
        val cols = max(1, floor((b.width() - 2 * pad + gap) / (s0 + gap)).toInt())
        val rows = max(1, floor((b.height() - 2 * pad + gap) / (s0 + gap)).toInt())
        return intArrayOf(cols, rows)
    }

    private fun slot(b: RectF, idx: Int, out: RectF): RectF {
        val (gc, gr) = gridOf(b).let { Pair(it[0], it[1]) }
        val pad = dp(9f)
        val cw = (b.width() - 2 * pad) / gc; val ch = (b.height() - 2 * pad) / gr
        val s = min(home.iconPx * 0.86f * fScale(), min(cw, ch) * 0.92f)
        val cx = b.left + pad + cw * (idx % gc + 0.5f); val cy = b.top + pad + ch * (idx / gc + 0.5f)
        out.set(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2); return out
    }

    private fun bigCount(): Int { val g = gridOf(bounds(RectF())); return min(g[0] * g[1], item.kids.size) }

    fun kidAt(x: Float, y: Float): Item? {
        if (!isBig()) return null
        val b = bounds(RectF()); val r = RectF()
        for (i in 0 until bigCount()) {
            slot(b, i, r); r.inset(-dp(4f), -dp(4f))
            if (r.contains(x, y)) return item.kids[i]
        }
        return null
    }

    private fun bmp(i: Item) = Icons.get(context, i.pkg, i.cls, (home.bmpPx * max(1f, iconMul)).toInt())

    override fun onDraw(c: Canvas) {
        val b = bounds(rf)
        p.style = Paint.Style.FILL; p.color = Color.WHITE
        if (item.isWidget) {
            val r = dp(22f); val s = snap
            if (s != null) { c.save(); c.clipPath(Path().apply { addRoundRect(b, r, r, Path.Direction.CW) }); c.drawBitmap(s, null, b, p); c.restore() }
            else { p.color = home.frostColor; c.drawRoundRect(b, r, r, p) }
            return
        }
        if (!item.isFolder) {
            bmp(item)?.let { c.drawBitmap(it, null, b, p) }
        } else {
            val pf = home.prefs; val r = fRadius(b)
            if (pf.folderBgOn) {
                Frost.drawSlice(c, home, this, b, r, home.folderTint, pf.folderBlur)
                if (pf.folderOutline) { p.style = Paint.Style.STROKE; p.strokeWidth = dp(1f); p.color = 0x66FFFFFF; c.drawRoundRect(b, r, r, p); p.style = Paint.Style.FILL }
            }
            p.color = Color.WHITE
            if (isBig()) {
                val t = RectF()
                for (i in 0 until bigCount()) bmp(item.kids[i])?.let { c.drawBitmap(it, null, slot(b, i, t), p) }
            } else {
                val n = item.kids.size; val g = if (home.prefs.folderGrid > 0) home.prefs.folderGrid else if (n <= 4) 2 else 3
                val pad = b.width() * 0.1f; val s = (b.width() - pad * 2) / g; val ins = max(-s * 0.05f, s * (0.08f + (1f - fScale()) * 0.5f))
                for (i in 0 until min(n, g * g)) {
                    dst.set(b.left + pad + (i % g) * s + ins, b.top + pad + (i / g) * s + ins,
                        b.left + pad + (i % g + 1) * s - ins, b.top + pad + (i / g + 1) * s - ins)
                    bmp(item.kids[i])?.let { c.drawBitmap(it, null, dst, p) }
                }
            }
        }
        if (showLabel()) {
            setupText()
            val t = TextUtils.ellipsize(item.label, tp, width - dp(6f), TextUtils.TruncateAt.END)
            c.drawText(t, 0, t.length, width / 2f, b.bottom + dp(4f) - tp.fontMetrics.ascent, tp)
        }
        if (rz > 0.01f) {
            drawResizeUi(c, this, this, b, (if (item.isFolder) fRadius(b) else dp(22f)) + dp(2f), rz)
        }
    }

    /** resize handles: 0 left, 1 top, 2 right, 3 bottom (on the outline) */
    override fun handleAt(i: Int): PointF {
        val o = bounds(RectF()); o.inset(-dp(2f), -dp(2f))
        return when (i) { 0 -> PointF(o.left, o.centerY()); 1 -> PointF(o.centerX(), o.top); 2 -> PointF(o.right, o.centerY()); else -> PointF(o.centerX(), o.bottom) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y
                animate().scaleX(0.92f).scaleY(0.92f).setDuration(Anim.d(110)).setInterpolator(Anim.out).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(Anim.d(320)).setInterpolator(Anim.pop).start()
        }
        return super.onTouchEvent(e)
    }
}

class CellLayout(ctx: Context, val home: HomeView) : ViewGroup(ctx) {
    var cols = 4; var rows = 5; var padX = 0f; var dockMode = false; var page = 0
    private val anims = HashMap<Item, ValueAnimator>()
    private val cur = HashMap<Item, RectF>()
    init { clipChildren = false; clipToPadding = false }

    val cellW get() = (width - 2 * padX) / cols
    val cellH get() = height.toFloat() / rows
    fun target(i: Item) = RectF(padX + i.x * cellW, i.y * cellH, padX + (i.x + i.sx) * cellW, (i.y + i.sy) * cellH)

    fun rebuild(list: List<Item>) {
        anims.values.forEach { it.cancel() }; anims.clear(); cur.clear(); removeAllViews()
        for (i in list) {
            if (i.isWidget) { addView(home.makeWidget(i)); continue }
            val v = CellView(context, i, home); v.dock = dockMode
            v.setOnClickListener { home.onItemClick(v) }
            v.setOnLongClickListener { home.onItemLong(v) }
            addView(v)
        }
    }

    override fun onMeasure(wm: Int, hm: Int) = setMeasuredDimension(MeasureSpec.getSize(wm), MeasureSpec.getSize(hm))
    override fun onLayout(c: Boolean, l: Int, t: Int, r: Int, b: Int) { for (n in 0 until childCount) place(getChildAt(n)) }

    private fun place(v: View) {
        val it0 = v.cellItem() ?: return
        val rc = cur[it0] ?: target(it0)
        val w = rc.width().roundToInt(); val h = rc.height().roundToInt()
        val l = rc.left.roundToInt(); val t = rc.top.roundToInt()
        v.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
        v.layout(l, t, l + w, t + h)
    }

    fun moveTo(item: Item) {
        val v = (0 until childCount).map { getChildAt(it) }.firstOrNull { it.cellItem() === item } ?: return
        val from = RectF(cur[item] ?: RectF(v.left.toFloat(), v.top.toFloat(), v.right.toFloat(), v.bottom.toFloat()))
        val to = target(item)
        anims[item]?.cancel()
        anims[item] = anim(0f, 1f, 320, Anim.out, end = { cur.remove(item); anims.remove(item); place(v) }) { t ->
            fun lerp(a: Float, b: Float) = a + (b - a) * t
            cur[item] = RectF(lerp(from.left, to.left), lerp(from.top, to.top), lerp(from.right, to.right), lerp(from.bottom, to.bottom))
            place(v)
        }
    }
}

class DotsView(ctx: Context) : View(ctx) {
    var count = 1; var pos = 0f; var dark = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val r = dp(3f); val gap = dp(8f); val extra = dp(10f)
        val total = count * 2 * r + (count - 1) * gap + extra
        var x = (width - total) / 2f; val y = height / 2f
        val base = if (dark) 0 else 255
        for (i in 0 until count) {
            val a = 1f - min(1f, abs(i - pos)); val w = 2 * r + extra * a
            p.color = Color.argb((110 + 145 * a).toInt(), base, base, base)
            c.drawRoundRect(x, y - r, x + w, y + r, r, r, p); x += w + gap
        }
    }
}


/** Hosts a real Android widget; long-press drags it, tap-release enters resize. */
class WidgetCell(ctx: Context, var item: Item, val home: HomeView, val hv: AppWidgetHostView?) : FrameLayout(ctx), Resizable {
    var rz = 0f; private var rzA: ValueAnimator? = null
    override var resizing: Boolean = false
        set(x) { field = x; rzA?.cancel(); rzA = anim(rz, if (x) 1f else 0f, 280, Anim.pop) { rz = it; invalidate() } }
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var dx = 0f; private var dy = 0f
    private val lp = Runnable { home.onItemLong(this) }
    private val sizeRun = Runnable {
        val d = resources.displayMetrics.density
        val wd = ((width - dpi(8f)) / d).toInt(); val hd = ((height - dpi(8f)) / d).toInt()
        if (wd > 0 && hd > 0) try { hv?.updateAppWidgetSize(Bundle(), wd, hd, wd, hd) } catch (e: Exception) {}
    }

    init {
        setPadding(dpi(4f), dpi(4f), dpi(4f), dpi(4f)); clipChildren = false; clipToPadding = false; setWillNotDraw(false)
        if (hv != null) {
            hv.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(22f)) }
            }
            hv.clipToOutline = true
            addView(hv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
    }

    fun bounds(o: RectF): RectF { o.set(dp(4f), dp(4f), width - dp(4f), height - dp(4f)); return o }
    override fun handleAt(i: Int): PointF {
        val o = bounds(RectF()); o.inset(-dp(2f), -dp(2f))
        return when (i) { 0 -> PointF(o.left, o.centerY()); 1 -> PointF(o.centerX(), o.top); 2 -> PointF(o.right, o.centerY()); else -> PointF(o.centerX(), o.bottom) }
    }
    fun snapshot(): Bitmap? = try {
        val b = Bitmap.createBitmap(max(1, width), max(1, height), Bitmap.Config.ARGB_8888); draw(Canvas(b)); b
    } catch (e: Exception) { null }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh); removeCallbacks(sizeRun); postDelayed(sizeRun, 150)
    }
    override fun dispatchDraw(c: Canvas) {
        super.dispatchDraw(c)
        if (rz > 0.01f) drawResizeUi(c, this, this, bounds(RectF()), dp(22f) + dp(2f), rz)
    }

    private fun track(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dx = e.x; dy = e.y; removeCallbacks(lp); postDelayed(lp, ViewConfiguration.getLongPressTimeout().toLong()) }
            MotionEvent.ACTION_MOVE -> if (hypot(e.x - dx, e.y - dy) > slop) removeCallbacks(lp)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(lp)
        }
    }
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean { track(e); return false }
    override fun onTouchEvent(e: MotionEvent): Boolean { track(e); return true }
    override fun onDetachedFromWindow() { removeCallbacks(lp); removeCallbacks(sizeRun); super.onDetachedFromWindow() }
}


/** the "+ Add" tile at the end of an opened folder */
class AddCell(ctx: Context, val home: HomeView, val mul: Float) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val r = RectF()
    init { isClickable = true }
    override fun onDraw(c: Canvas) {
        tp.textSize = home.labelPx; tp.color = home.labelColor; tp.setShadowLayer(dp(2f), 0f, dp(1f), 0x66000000)
        val lh = tp.fontSpacing + dp(4f); val ic = home.iconPx * mul
        val top = (height - ic - lh) / 2f; val l = (width - ic) / 2f
        r.set(l, top, l + ic, top + ic)
        p.style = Paint.Style.FILL; p.color = if (isPressed) 0x77FFFFFF else 0x55FFFFFF
        c.drawRoundRect(r, ic * 0.24f, ic * 0.24f, p)
        p.color = Color.WHITE; p.style = Paint.Style.STROKE; p.strokeWidth = dp(2.6f); p.strokeCap = Paint.Cap.ROUND
        val a = ic * 0.2f
        c.drawLine(r.centerX() - a, r.centerY(), r.centerX() + a, r.centerY(), p)
        c.drawLine(r.centerX(), r.centerY() - a, r.centerX(), r.centerY() + a, p)
        c.drawText("Add", width / 2f, r.bottom + dp(4f) - tp.fontMetrics.ascent, tp)
    }
}
