package com.example.launcher

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat

class MainActivity : Activity() {
    lateinit var home: HomeView
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { Apps.load(this@MainActivity); home.rebuildAll() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 29) { window.isNavigationBarContrastEnforced = false; window.isStatusBarContrastEnforced = false }
        Apps.load(this)
        home = HomeView(this)
        setContentView(home)
        home.start()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onResume() {
        super.onResume()
        val p = home.prefs
        if (p.dirty) { p.dirty = false; Apps.load(this); home.reload() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) home.onHomePressed()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { home.onBack() }

    override fun onDestroy() { unregisterReceiver(receiver); super.onDestroy() }
}
