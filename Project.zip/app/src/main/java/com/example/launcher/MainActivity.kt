package com.example.launcher

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat

class MainActivity : Activity() {
    lateinit var home: HomeView
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { Apps.load(this@MainActivity); home.rebuildAll() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 29) { window.isNavigationBarContrastEnforced = false; window.isStatusBarContrastEnforced = false }
        Apps.load(this)
        home = HomeView(this)
        setContentView(home)
        home.start()
        if (!Frost.hasAccess(this) && home.prefs.blur && !home.prefs.askedAccess) {
            home.prefs.askedAccess = true
            if (Build.VERSION.SDK_INT in 23..32) requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 7)
            else if (Build.VERSION.SDK_INT >= 33) android.app.AlertDialog.Builder(this).setTitle("Blur needs wallpaper access")
                .setMessage("To blur your wallpaper behind the dock and folders, the launcher needs 'All files access' (Android only lets apps read the wallpaper with it).")
                .setPositiveButton("Allow") { _, _ ->
                    try { startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, android.net.Uri.parse("package:$packageName"))) } catch (e: Exception) {}
                }.setNegativeButton("Not now", null).show()
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, receiver, f, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onStart() { super.onStart(); try { home.widgetHost.startListening() } catch (e: Exception) {} }
    override fun onStop() { super.onStop(); try { home.widgetHost.stopListening() } catch (e: Exception) {} }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data); home.onActivityResult(req, res)
    }

    override fun onResume() {
        super.onResume()
        val p = home.prefs
        if (p.dirty) { p.dirty = false; Apps.load(this); home.reload() }
        home.post { home.loadFrost(true); home.refreshRecents() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) home.onHomePressed()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { home.onBack() }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res); home.loadFrost(true)
    }

    override fun onDestroy() { unregisterReceiver(receiver); super.onDestroy() }
}
