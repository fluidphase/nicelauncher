package com.example.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

class SettingsActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var box: LinearLayout
    private lateinit var card: LinearLayout

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        p = Prefs(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val sv = ScrollView(this); sv.setBackgroundColor(0xFFF4F5F9.toInt())
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(18f), dpi(16f), dpi(18f), dpi(40f)) }
        sv.addView(box)
        ViewCompat.setOnApplyWindowInsetsListener(sv) { v, w ->
            val b = w.getInsets(WindowInsetsCompat.Type.systemBars()); v.setPadding(0, b.top, 0, b.bottom); w
        }
        WindowCompat.getInsetsController(window, sv).isAppearanceLightStatusBars = true
        setContentView(sv)
        box.addView(TextView(this).apply { text = "Home settings"; textSize = 30f; setTextColor(0xFF111318.toInt()); setPadding(dpi(6f), dpi(12f), 0, dpi(8f)) })

        head("Layout")
        choice("Home layout", arrayOf("Standard (all apps on home)", "With app drawer"), { if (p.standard) 0 else 1 }) { p.standard = it == 0 }
        seek("Grid columns", 0, 12, { p.cols }, { p.cols = if (it in 1..2) 3 else it }) { if (it == 0) "Auto" else "$it" }
        seek("Grid rows", 0, 10, { p.rows }, { p.rows = if (it in 1..2) 3 else it }) { if (it == 0) "Auto" else "$it" }
        sw("Lock layout", { p.lock }) { p.lock = it }
        sw("Page indicator", { p.indicator }) { p.indicator = it }
        sw("Search pill", { p.searchPill }) { p.searchPill = it }

        head("Icons & labels")
        seek("Icon size", 60, 140, { p.iconScale }, { p.iconScale = it }) { "$it%" }
        choice("Icon shape", arrayOf("Squircle", "Circle", "Square", "Rounded square"), { p.shape }) { p.shape = it }
        sw("Show labels", { p.labels }) { p.labels = it }
        seek("Label size", 9, 16, { p.labelSize }, { p.labelSize = it }) { "$it sp" }
        sw("Dark labels (for light wallpapers)", { p.darkLabels }) { p.darkLabels = it }

        head("Folders & dock")
        seek("Folder / dock opacity", 5, 80, { p.frost }, { p.frost = it }) { "$it%" }

        head("Animation")
        seek("Animation duration", 0, 200, { p.animPct }, { p.animPct = it }) { if (it == 0) "Off" else "$it%" }

        head("Other")
        button("Set as default home app") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        button("Reset home layout") {
            AlertDialog.Builder(this).setTitle("Reset layout?").setMessage("Folders and positions will be cleared.")
                .setPositiveButton("Reset") { _, _ -> getSharedPreferences("layout", MODE_PRIVATE).edit().clear().apply(); p.dirty = true; finish() }
                .setNegativeButton("Cancel", null).show()
        }
    }

    private fun newCard(): LinearLayout {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.WHITE, dp(22f)); setPadding(dpi(18f), dpi(6f), dpi(18f), dpi(6f)) }
        box.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dpi(6f) })
        return c
    }
    private fun head(t: String) {
        box.addView(TextView(this).apply { text = t.uppercase(); textSize = 12f; letterSpacing = 0.08f; setTextColor(0xFF6B7280.toInt()); setPadding(dpi(8f), dpi(16f), 0, dpi(8f)) })
    }
    private fun sw(t: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        card.addView(Switch(this).apply {
            text = t; textSize = 16f; setTextColor(0xFF111318.toInt()); isChecked = get(); setPadding(0, dpi(14f), 0, dpi(14f))
            setOnCheckedChangeListener { _, v -> set(v); p.dirty = true }
        })
    }
    private fun seek(t: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit, fmt: (Int) -> String) {
        val label = TextView(this).apply { textSize = 16f; setTextColor(0xFF111318.toInt()); text = "$t · ${fmt(get())}"; setPadding(0, dpi(12f), 0, 0) }
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = get() - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, pr: Int, user: Boolean) { label.text = "$t · ${fmt(pr + min)}"; if (user) { set(pr + min); p.dirty = true } }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        card.addView(label); card.addView(sb)
    }
    private fun choice(t: String, opts: Array<String>, get: () -> Int, set: (Int) -> Unit) {
        val tv = TextView(this).apply {
            textSize = 16f; setTextColor(0xFF111318.toInt()); setPadding(0, dpi(14f), 0, dpi(14f))
            text = "$t\n${opts[get()]}"
            setOnClickListener {
                AlertDialog.Builder(this@SettingsActivity).setTitle(t).setSingleChoiceItems(opts, get()) { d, w ->
                    set(w); p.dirty = true; text = "$t\n${opts[w]}"; d.dismiss()
                }.show()
            }
        }
        card.addView(tv)
    }
    private fun button(t: String, click: () -> Unit) {
        card.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { click() } },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dpi(6f); bottomMargin = dpi(6f); gravity = Gravity.CENTER })
    }
}
