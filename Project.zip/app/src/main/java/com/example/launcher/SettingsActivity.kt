package com.example.launcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

class SettingsActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var box: LinearLayout
    private var card: LinearLayout? = null

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        p = Prefs(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val sv = ScrollView(this); sv.setBackgroundColor(0xFFF4F5F9.toInt())
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(18f), dpi(16f), dpi(18f), dpi(40f)) }
        sv.addView(box)
        ViewCompat.setOnApplyWindowInsetsListener(sv) { v, w ->
            val b = w.getInsets(WindowInsetsCompat.Type.systemBars()); v.setPadding(0, b.top, 0, b.bottom); w
        }
        WindowCompat.getInsetsController(window, sv).isAppearanceLightStatusBars = true
        setContentView(sv)
        box.addView(TextView(this).apply { text = "Home settings"; textSize = 30f; setTextColor(0xFF111318.toInt()); setPadding(dpi(6f), dpi(12f), 0, dpi(8f)) })

        head("Layout")
        choice("Home layout", arrayOf("Standard (all apps on home)", "With app drawer"), { if (p.standard) 0 else 1 }) { p.standard = it == 0 }
        seek("Grid columns", 0, 12, { p.cols }, { p.cols = if (it in 1..2) 3 else it }) { if (it == 0) "Auto" else "$it" }
        seek("Grid rows", 0, 10, { p.rows }, { p.rows = if (it in 1..2) 3 else it }) { if (it == 0) "Auto" else "$it" }
        seek("App library columns", 0, 8, { p.drawerCols }, { p.drawerCols = if (it in 1..2) 3 else it }) { if (it == 0) "Auto" else "$it" }
        sw("Lock layout", { p.lock }) { p.lock = it }
        sw("Page indicator", { p.indicator }) { p.indicator = it }
        sw("Search pill", { p.searchPill }) { p.searchPill = it }

        head("Icons & labels")
        pick("Icon pack", { packName(p.iconPack) }) { refresh -> choosePack(refresh) }
        choice("Icon shape", arrayOf("Circle", "Squircle", "Rounded square", "Square"), { p.shape }) { p.shape = it }
        seek("Icon size", 60, 140, { p.iconScale }, { p.iconScale = it }) { "$it%" }
        sw("Show labels", { p.labels }) { p.labels = it }
        seek("Label size", 9, 16, { p.labelSize }, { p.labelSize = it }) { "$it sp" }
        sw("Dark labels (for light wallpapers)", { p.darkLabels }) { p.darkLabels = it }

        head("Folders")
        sw("Show folder background", { p.folderBgOn }) { p.folderBgOn = it }
        sw("Blur wallpaper behind folders", { p.folderBlur }) { p.folderBlur = it }
        choice("Folder color", arrayOf("White", "Black", "Blue", "Green", "Pink", "Orange"), { p.folderColor }) { p.folderColor = it }
        seek("Folder opacity", 0, 100, { p.folderOpacity }, { p.folderOpacity = it }) { "$it%" }
        seek("Folder corner radius", 0, 50, { p.folderRadius }, { p.folderRadius = it }) { "$it%" }
        seek("Folder icon size", 50, 120, { p.folderIconScale }, { p.folderIconScale = it }) { "$it%" }
        choice("Folder preview grid", arrayOf("Auto", "2 x 2", "3 x 3"), { if (p.folderGrid == 2) 1 else if (p.folderGrid == 3) 2 else 0 }) { p.folderGrid = intArrayOf(0, 2, 3)[it] }
        sw("Folder outline", { p.folderOutline }) { p.folderOutline = it }
        sw("Folder names", { p.folderLabels }) { p.folderLabels = it }

        head("Opened folders")
        choice("Style", arrayOf("Full screen (like Honor)", "Floating card"), { p.fpStyle }) { p.fpStyle = it }
        seek("Icon size (full screen)", 70, 150, { p.fpIconScale }, { p.fpIconScale = it }) { "$it%" }
        sw("'Add' button (full screen)", { p.fpAdd }) { p.fpAdd = it }
        choice("Card color", arrayOf("White", "Black", "Blue", "Green", "Pink", "Orange"), { p.fpColor }) { p.fpColor = it }
        seek("Card opacity", 0, 100, { p.fpOpacity }, { p.fpOpacity = it }) { "$it%" }
        seek("Card corner radius", 0, 50, { p.fpRadius }, { p.fpRadius = it }) { "$it dp" }
        sw("Blur wallpaper behind card", { p.fpBlur }) { p.fpBlur = it }
        sw("Card outline", { p.fpOutline }) { p.fpOutline = it }
        seek("Columns", 0, 6, { p.fpCols }, { p.fpCols = if (it == 1) 2 else it }) { if (it == 0) "Auto" else "$it" }
        seek("Background dim (folders & app library)", 0, 80, { p.folderDim }, { p.folderDim = it }) { "$it%" }

        head("Dock")
        seek("Dock height", 60, 130, { p.dockHeight }, { p.dockHeight = it }) { "$it dp" }
        seek("Dock icon size", 50, 130, { p.dockIconScale }, { p.dockIconScale = it }) { "$it%" }
        seek("Dock bottom margin", 0, 40, { p.dockMargin }, { p.dockMargin = it }) { "$it dp" }
        seek("Dock corner radius", 0, 50, { p.dockRadius }, { p.dockRadius = it }) { "$it%" }
        seek("Dock opacity", 0, 100, { p.dockOpacity }, { p.dockOpacity = it }) { "$it%" }
        choice("Dock color", arrayOf("White", "Black", "Blue", "Green", "Pink", "Orange"), { p.dockColor }) { p.dockColor = it }
        sw("Show dock background", { p.dockBgOn }) { p.dockBgOn = it }
        sw("Blur wallpaper behind dock", { p.dockBlur }) { p.dockBlur = it }
        sw("Dock outline", { p.dockOutline }) { p.dockOutline = it }
        sw("Dock labels", { p.dockLabels }) { p.dockLabels = it }
        seek("Dock width", 0, 100, { p.dockWidth }, { p.dockWidth = if (it in 1..39) 40 else it }) { if (it == 0) "Fit icons" else "$it%" }
        seek("Icon spacing", 0, 40, { p.dockSpace }, { p.dockSpace = it }) { if (it == 0) "Auto" else "$it dp" }
        seek("Dock inner padding", 0, 24, { p.dockPad }, { p.dockPad = it }) { "$it dp" }
        sw("Dock fills the full width", { p.dockFull }) { p.dockFull = it }
        seek("Max dock icons", 0, 8, { p.dockMax }, { p.dockMax = if (it in 1..2) 3 else it }) { if (it == 0) "Auto" else "$it" }
        sw("Recents dock (next to the dock)", { p.recentsDock }) { p.recentsDock = it }
        choice("Recents style", arrayOf("Joined, with divider line", "Separate dock"), { if (p.recentsJoined) 0 else 1 }) { p.recentsJoined = it == 0 }
        sw("Divider line", { p.recentsDivider }) { p.recentsDivider = it }
        seek("Recents dock icons", 1, 5, { p.recentsMax }, { p.recentsMax = it }) { "$it" }

        head("Blur")
        sw("Blur dock, folders & backdrop", { p.blur }) { p.blur = it }
        seek("Blur strength", 2, 14, { p.blurAmt }, { p.blurAmt = it }) { "$it" }
        pick("Blur status", { Frost.status }) { }
        button("Allow wallpaper access (needed for blur)") { askStorage() }

        head("Menus")
        sw("Dark popup menus", { p.popupDark }) { p.popupDark = it }

        head("Animation")
        choice("App open / close animation", arrayOf("Zoom from icon (HarmonyOS-like)", "System default zoom", "None"), { p.launchStyle }) { p.launchStyle = it }
        choice("Opening window color", arrayOf("Auto (from the icon)", "Dark", "Light"), { p.launchColor }) { p.launchColor = it }
        seek("Animation duration", 0, 200, { p.animPct }, { p.animPct = it }) { if (it == 0) "Off" else "$it%" }

        head("Other")
        button("Set as default home app") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        button("Reset home layout") {
            AlertDialog.Builder(this).setTitle("Reset layout?").setMessage("Folders and positions will be cleared.")
                .setPositiveButton("Reset") { _, _ -> getSharedPreferences("layout", MODE_PRIVATE).edit().clear().apply(); p.dirty = true; finish() }
                .setNegativeButton("Cancel", null).show()
        }
    }

    private fun askStorage() {
        if (Build.VERSION.SDK_INT >= 30 && Build.VERSION.SDK_INT < 33 && !Frost.hasAccess(this)) {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 7)
        } else if (Build.VERSION.SDK_INT >= 33) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
            catch (e: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
        } else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 7)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        p.dirty = true
        if (res.isNotEmpty() && res[0] != android.content.pm.PackageManager.PERMISSION_GRANTED && Build.VERSION.SDK_INT >= 30) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) } catch (e: Exception) {}
        }
    }

    override fun onResume() { super.onResume(); p.dirty = true }

    private fun packName(pkg: String): String =
        if (pkg.isEmpty()) "System default" else IconPack.find(this).firstOrNull { it.first == pkg }?.second ?: pkg

    private fun choosePack(refresh: () -> Unit) {
        val packs = IconPack.find(this)
        if (packs.isEmpty()) { Toast.makeText(this, "No icon packs installed", Toast.LENGTH_SHORT).show(); return }
        val names = (listOf("System default") + packs.map { it.second }).toTypedArray()
        AlertDialog.Builder(this).setTitle("Icon pack").setItems(names) { _, w ->
            p.iconPack = if (w == 0) "" else packs[w - 1].first; p.dirty = true; refresh()
        }.show()
    }

    // ---------- ui helpers ----------
    private fun head(t: String) {
        box.addView(TextView(this).apply { text = t.uppercase(); textSize = 12f; letterSpacing = 0.08f; setTextColor(0xFF6B7280.toInt()); setPadding(dpi(8f), dpi(16f), 0, dpi(8f)) })
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.WHITE, dp(22f)); setPadding(dpi(18f), dpi(6f), dpi(18f), dpi(6f)) }
        box.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dpi(6f) })
        card = c
    }
    private fun sw(t: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        card!!.addView(Switch(this).apply {
            text = t; textSize = 16f; setTextColor(0xFF111318.toInt()); isChecked = get(); setPadding(0, dpi(14f), 0, dpi(14f))
            setOnCheckedChangeListener { _, v -> set(v); p.dirty = true }
        })
    }
    private fun seek(t: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit, fmt: (Int) -> String) {
        val label = TextView(this).apply { textSize = 16f; setTextColor(0xFF111318.toInt()); text = "$t · ${fmt(get())}"; setPadding(0, dpi(12f), 0, 0) }
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = get() - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, pr: Int, user: Boolean) { label.text = "$t · ${fmt(pr + min)}"; if (user) { set(pr + min); p.dirty = true } }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        card!!.addView(label); card!!.addView(sb)
    }
    private fun pick(t: String, value: () -> String, onClick: (() -> Unit) -> Unit) {
        val tv = TextView(this).apply { textSize = 16f; setTextColor(0xFF111318.toInt()); setPadding(0, dpi(14f), 0, dpi(14f)); text = "$t\n${value()}" }
        tv.setOnClickListener { onClick { tv.text = "$t\n${value()}" } }
        card!!.addView(tv)
    }
    private fun choice(t: String, opts: Array<String>, get: () -> Int, set: (Int) -> Unit) {
        pick(t, { opts[get().coerceIn(0, opts.size - 1)] }) { refresh ->
            AlertDialog.Builder(this).setTitle(t).setSingleChoiceItems(opts, get()) { d, w -> set(w); p.dirty = true; refresh(); d.dismiss() }.show()
        }
    }
    private fun button(t: String, click: () -> Unit) {
        card!!.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { click() } },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dpi(6f); bottomMargin = dpi(6f); gravity = Gravity.CENTER })
    }
}
