package com.gamelauncher.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private data class Game(val label: String, val icon: Drawable, val intent: Intent)

    private val bg = Color.parseColor("#0B0B1E")
    private val card = Color.parseColor("#16163A")
    private val cyan = Color.parseColor("#00E5FF")
    private val pink = Color.parseColor("#FF2D95")

    private lateinit var root: FrameLayout
    private var renderToken = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this).apply {
            fitsSystemWindows = true
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#1A0B3B"), bg)
            )
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        render()
    }

    @Deprecated("Launcher should stay on the home screen")
    override fun onBackPressed() { /* stay on home */ }

    // ---------- state ----------

    private fun isDefaultLauncher(): Boolean {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    private fun render() {
        renderToken++
        root.removeAllViews()
        if (isDefaultLauncher()) showLibrary() else showGate()
    }

    // ---------- gate screen ----------

    private fun showGate() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        col.addView(title("GAME\nLAUNCHER", 40f, cyan).apply { gravity = Gravity.CENTER })
        col.addView(title("PRESS START", 14f, pink).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(48))
        })
        val btn = neonButton("SET AS DEFAULT LAUNCHER", cyan) { requestDefault() }
        col.addView(btn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ObjectAnimator.ofFloat(btn, View.ALPHA, 1f, 0.55f).apply {
            duration = 800
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        root.addView(col, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    // ---------- library screen ----------

    private fun showLibrary() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        col.addView(title("▶ GAME LIBRARY", 20f, cyan).apply {
            setPadding(dp(20), dp(16), dp(20), dp(8))
        })

        val status = title("LOADING...", 14f, pink).apply { gravity = Gravity.CENTER }
        val grid = GridView(this).apply {
            numColumns = 4
            horizontalSpacing = dp(10)
            verticalSpacing = dp(10)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            clipToPadding = false
            selector = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
            emptyView = status
        }
        val gridFrame = FrameLayout(this)
        gridFrame.addView(grid)
        gridFrame.addView(status, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        col.addView(gridFrame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        col.addView(neonButton("RETURN TO DEFAULT", pink) { openHomeSettings() },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(20), dp(8), dp(20), dp(16)) })

        root.addView(col, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val token = renderToken
        Thread {
            val games = loadGames()
            runOnUiThread {
                if (token != renderToken) return@runOnUiThread
                status.text = "NO GAMES FOUND"
                grid.adapter = GameAdapter(games)
                grid.setOnItemClickListener { _, _, pos, _ -> launch(games[pos]) }
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun loadGames(): List<Game> {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(main, 0)
            .filter { ri ->
                val ai = ri.activityInfo.applicationInfo
                ai.packageName != packageName &&
                    (ai.category == ApplicationInfo.CATEGORY_GAME ||
                        (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0)
            }
            .map { ri ->
                val intent = Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                Game(ri.loadLabel(pm).toString(), ri.loadIcon(pm), intent)
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun launch(game: Game) {
        try {
            startActivity(game.intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't launch ${game.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private inner class GameAdapter(private val games: List<Game>) : BaseAdapter() {
        override fun getCount() = games.size
        override fun getItem(position: Int) = games[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val g = games[position]
            return LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(4), dp(10), dp(4), dp(8))
                background = GradientDrawable().apply {
                    setColor(card)
                    cornerRadius = dp(12).toFloat()
                    setStroke(dp(1), Color.parseColor("#3300E5FF"))
                }
                addView(ImageView(this@MainActivity).apply { setImageDrawable(g.icon) },
                    LinearLayout.LayoutParams(dp(52), dp(52)))
                addView(TextView(this@MainActivity).apply {
                    text = g.label
                    setTextColor(Color.WHITE)
                    textSize = 10f
                    typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                    gravity = Gravity.CENTER
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(0, dp(6), 0, 0)
                })
            }
        }
    }

    // ---------- default launcher actions ----------

    private fun requestDefault() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(Context.ROLE_SERVICE) as RoleManager
                if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 1)
                    return
                }
            }
        } catch (_: Exception) { }
        openHomeSettings()
    }

    private fun openHomeSettings() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Open Settings > Apps > Default apps > Home app", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---------- ui helpers ----------

    private fun title(text: String, size: Float, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        letterSpacing = 0.12f
        setShadowLayer(18f, 0f, 0f, color)
    }

    private fun neonButton(text: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(color)
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        letterSpacing = 0.1f
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setShadowLayer(12f, 0f, 0f, color)
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#22000000"))
            cornerRadius = dp(14).toFloat()
            setStroke(dp(2), color)
        }
        setOnClickListener { onClick() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
